﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BPAS;
using BusinessLogicLayer.CMS;
using EntityLayer.CMS;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Net;
using RestSharp;
using System.Web.Script.Serialization;
using System.Security.Cryptography;
using System.IO;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

public partial class ServiceInstructionExternal : System.Web.UI.Page
{
    #region Globalvariable
    /// <summary>
    /// Prasun Kali
    /// All global variable are declared here
    /// </summary>
    string str_FormId = "";
    int Int_ServiceType = 0;

    string str_ProposalNo = "";
    string str_Amount = "0";
    string str_RequestMode = "";
    CmsBusinesslayer objService = new CmsBusinesslayer();
   
    SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["AdminAppConnectionProd"].ToString());
   
    
    ExternalServiceIntegration objSvc = new ExternalServiceIntegration();
   
    #endregion

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["InvestorId"] == null)
        {
            Response.Redirect("~/Login.aspx");
        }

        myNavbar.Visible = false;

        if (Request.QueryString["ReqMode"] != "" && Request.QueryString["ReqMode"] != null)
        {
            str_RequestMode = Request.QueryString["ReqMode"].ToString();

            if (Request.QueryString["FormId"] != "" && Request.QueryString["FormId"] != null)
            {
                str_FormId = Request.QueryString["FormId"].ToString();
                Int_ServiceType = Convert.ToInt32(Request.QueryString["ServiceType"].ToString());
                str_ProposalNo = Request.QueryString["ProposalNo"].ToString();
                str_Amount = Request.QueryString["Amount"].ToString();
                FillContent();
                lblService.Text = GetServiceName(Request.QueryString["FormId"].ToString());
            }
        }
    }

    public string GetServiceName(string strServiceID)
    {
        string strRes = "";
        SqlCommand cmd = new SqlCommand("SELECT VCH_SERVICENAME,(SELECT nvchLevelName FROM M_ADM_LevelDetails WHERE intLevelId=2 AND intLevelDetailId=INT_DEPARTMENT_ID) As Department FROM M_SERVICEMASTER_TBL WHERE  INT_SERVICEID=" + strServiceID, conn);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            strRes = ds.Tables[0].Rows[0][1].ToString() + " > " + ds.Tables[0].Rows[0][0].ToString();

        }
        return strRes;
    }
    private void FillContent()
    {
        try
        {
            EntityLayer.CMS.CMSDetails objServiceEntity = new EntityLayer.CMS.CMSDetails();
            objServiceEntity.StrAction = "GCD";
            objServiceEntity.IntServiceId = Convert.ToInt32(str_FormId);
            IList<CMSDetails> obj = objService.GetCMSData(objServiceEntity);
            if (obj.Count > 0)
            {
                divabout.InnerHtml = obj[0].StrContent;
                HyprLnk.NavigateUrl = obj[0].strAttachment;
            }
            
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this, typeof(Page), "Failure", "jAlert('" + ex.ToString().Replace("'", "") + "');", true);
        }
    }
   

    protected void BtnProceed_Click(object sender, EventArgs e)
    {
        try
        {
            if (str_FormId == "52") // Trade Licenece Service
            {
                //Response.Redirect("TradeLicenceData.aspx?FormId=" + str_FormId.ToString() + "&ProposalNo=" + str_ProposalNo);

                lblMessage.Text = "Trade Licenece Service";
                ServiceModalPopup.Show();
            }
            else if (str_FormId == "30" || str_FormId == "31" || str_FormId == "32") // DrugLicense Service
            {
                lblMessage.Text = "Health and Family Welfare";
                ServiceModalPopup.Show();
            }
            else if (str_FormId == "43" || str_FormId == "44" || str_FormId == "45" || str_FormId == "46" || str_FormId == "50" || str_FormId == "53" || str_FormId == "54" || str_FormId == "65" || str_FormId == "66" || str_FormId == "76" || str_FormId == "77" || str_FormId == "78" || str_FormId == "79") // Pollution Control Board
            {
                lblMessage.Text = "Odisha State Pollution Control Board";
                ServiceModalPopup.Show();
            }
            else if (str_FormId == "25" || str_FormId == "26") // Tree Transit Service
            {
                lblMessage.Text = "Forest and Environment";
                ServiceModalPopup.Show();
            }
            else if (str_FormId == "28") // Land Allocated Service
            {
                Response.Redirect("LandAllocated.aspx?ServiceID=" + str_FormId.ToString() + "&ProposalNo=" + str_ProposalNo + "&UserId=" + Session["InvestorId"].ToString());
            }
            else if (str_FormId == "49") // PartnershipFirm Service
            {
                lblMessage.Text = "Revenue & Disaster Management";
                ServiceModalPopup.Show();
            }
            else if (str_FormId == "10")
            {
                Response.Redirect("ProfessionalTaxData.aspx?FormId=" + str_FormId.ToString() + "&ProposalNo=" + str_ProposalNo);
            }
            else if (str_FormId == "20") // Building Plan Approval Service
            {
                lblMessage.Text = "Housing and Urban Development";
                ServiceModalPopup.Show();
            }
            else if (str_FormId == "29") // Obtaining water connection
            {
                lblMessage.Text = "IDCO";
                ServiceModalPopup.Show();
            }           
            else if (str_FormId == "5" || str_FormId == "6" || str_FormId == "7" || str_FormId == "34" || str_FormId == "35" || str_FormId == "36" || str_FormId == "39" || str_FormId == "40" || str_FormId == "70" || str_FormId == "71" || str_FormId == "72" || str_FormId == "37") //F&B and Labour Service form id 37 add by anil
            {
                lblMessage.Text = "PAReSHRAM";
                ServiceModalPopup.Show();
            }
            
            else if (str_FormId == "62" || str_FormId == "63") // Fire Service
            {
                lblMessage.Text = "Directorate General Fire Services, Home Guards & Civil Defence";
                ServiceModalPopup.Show();
            }
            else if (str_FormId == "67" || str_FormId == "68") // Excise Service
            {
                lblMessage.Text = "Odisha State Excise";
                ServiceModalPopup.Show();
            }
            else if (str_FormId == "69") // OSBC Service
            {
                lblMessage.Text = "Odisha State Beverages Corporation Limited";
                ServiceModalPopup.Show();
            }
            else if (str_FormId == "73") // Mobile Tower Service
            {
                lblMessage.Text = "Department of Electronics and Information Technologies (E & IT)";
                ServiceModalPopup.Show();
            }
            else if (str_FormId == "74") // DG SET INSTALLATION
            {
                lblMessage.Text = "Department of Energy";
                ServiceModalPopup.Show();
            }
            else if (str_FormId == "16") // New Power Connection Service
            {
                lblMessage.Text = "New Power connection";
                ServiceModalPopup.Show();
            }

        }
        catch (Exception ex)
        {
            Util.LogError(ex, "ServiceRedirect");
        }
    }

    protected void BtnYes_Click(object sender, EventArgs e)
    {
        lblMessage.Text = "";
        ServiceModalPopup.Hide();
        string strEncriptData = "";
        string strResult = "";
        try
        {

        

            if (str_FormId == "30" || str_FormId == "31" || str_FormId == "32") // DrugLicense Service
            {
                    //Response.Redirect(ConfigurationManager.AppSettings["DrugLicense"].ToString() + "?ServiceID=" + str_FormId.ToString() + "&UserId=" +     Session["InvestorId"].ToString() + "&ProposalNo=" + str_ProposalNo);
            
                    strEncriptData = DRUG();
                    Util.LogRequestResponse("DrugService", "Encriptiondata", strEncriptData);
                    #region For allow https from http url this below part need to add
            
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12 |     SecurityProtocolType.Ssl3;
                    ServicePointManager.SecurityProtocol = (SecurityProtocolType)768 | (SecurityProtocolType)3072;

                    #endregion
                    string strDRUGURL = ConfigurationManager.AppSettings["DrugsLicenseUrl"].ToString();
                    Util.LogRequestResponse("DrugService", "DrugsURL", strDRUGURL);
                    var Client = new RestClient(strDRUGURL);
                    Client.Timeout = -1;
                    var Request = new RestRequest(Method.POST);
                
                    Request.AddHeader("Content-Type", "application/json");
                    Request.AddParameter("application/json", strEncriptData, ParameterType.RequestBody);
                    IRestResponse dataResponse = Client.Execute(Request);
                    Util.LogRequestResponse("DrugService", "StatusCode", dataResponse.StatusCode.ToString());
                    Util.LogRequestResponse("DrugService", "ResponseContent", dataResponse.Content.ToString());
                    if (dataResponse.StatusCode == HttpStatusCode.OK) 
                    {
                       string JSON = dataResponse.Content;
                       dynamic data = JObject.Parse(JSON);//success
                       Util.LogRequestResponse("DrugService", "ApiSuccess", data["success"].ToString());

                       if (Convert.ToBoolean(data["success"]))
                       {
                        string strRedirectionUrl = Convert.ToString(data["redirect_url"]);
                        Util.LogRequestResponse("DrugService", "RedirectionUrl", strRedirectionUrl);
                        Response.Redirect(strRedirectionUrl);
                       }
                       else
                       {
                        Util.LogRequestResponse("DrugService", "FailureResponseContent", dataResponse.Content.ToString());
                       }
                    }


            }
            else if (str_FormId == "43" || str_FormId == "44" || str_FormId == "45" || str_FormId == "46" || str_FormId == "50" || str_FormId == "53" ||     str_FormId == "54" || str_FormId == "65" || str_FormId == "66" || str_FormId == "76" || str_FormId == "77" || str_FormId == "78" ||    str_FormId  == "79") // Pollution Control Board
            {
                Response.Redirect(ConfigurationManager.AppSettings["PollutionControl"].ToString() + "?ServiceID=" + str_FormId.ToString() + "&UserId=" +    Session ["InvestorId"].ToString() + "&StrProposalID=" + str_ProposalNo);
            }
            else if (str_FormId == "25" || str_FormId == "26") // Tree Transit (Forest department) Service
            {
            
                    strEncriptData = FOREST();
                Response.Redirect(ConfigurationManager.AppSettings["TreeTransit"].ToString() + "?" + strEncriptData + "");
            }
            else if (str_FormId == "49") // PartnershipFirm Service
            {
                Response.Redirect(ConfigurationManager.AppSettings["PartnershipFirm"].ToString() + "?UserId=" + Session["InvestorId"].ToString() +     "&ProposalId=" + str_ProposalNo);
            }
            else if (str_FormId == "20") // Building Plan Approval Service
            {
                    strEncriptData = BPAS();
                Response.Redirect(ConfigurationManager.AppSettings["BPASRedirectionURL"].ToString() + strEncriptData);
            }
            else if (str_FormId == "29") // Obtaining water connection
            {
                    strEncriptData = GOIPAS();
                Response.Redirect(ConfigurationManager.AppSettings["GOIPASRedirectionURL"].ToString() + "?Query=" + strEncriptData + "");
            }
            else if (str_FormId == "5" || str_FormId == "6" || str_FormId == "7" || str_FormId == "34" || str_FormId == "35" || str_FormId == "36" ||    str_FormId  == "39" || str_FormId == "40" || str_FormId == "70" || str_FormId == "71" || str_FormId == "72" || str_FormId == "37") //F&B and    Labour Service  -- 37 Add by anil
            {
                    strEncriptData = PAReSHRAM();
                Response.Redirect(ConfigurationManager.AppSettings["PARESHRAMREDIRECTIONURL"].ToString() + "?" + strEncriptData + "");
            }
            
            else if (str_FormId == "62" || str_FormId == "63") // Fire Service
            {
                strEncriptData = FIRE();
                System.Threading.Thread.Sleep(10000);
                Response.Redirect(ConfigurationManager.AppSettings["FIREREDIRECTIONURL"].ToString() + "?Query=" + strEncriptData + "");
                System.Threading.Thread.Sleep(10000);
                Util.LogRequestResponse("FireService", "RediractioUlr", "RediractioUlr :-" + ConfigurationManager.AppSettings["FIREREDIRECTIONURL"].ToString   ());
            }
            else if (str_FormId == "67" || str_FormId == "68") // Excise Service
            {
                if (str_FormId == "67")
                {
                      strEncriptData = EXCISE();
                    #region For allow https from http url this below part need to add
            
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12 |     SecurityProtocolType.Ssl3;
                    ServicePointManager.SecurityProtocol = (SecurityProtocolType)768 | (SecurityProtocolType)3072;
            
                    #endregion
                    var client = new RestClient(ConfigurationManager.AppSettings["EXCISESRREDIRECTIONURL"].ToString());
                        client.FollowRedirects = false;
                    Util.LogRequestResponse("EabakaryService", "Url :-", "Url :-" + ConfigurationManager.AppSettings["EXCISESRREDIRECTIONURL"].ToString());
                    client.Timeout = -1;
                    var request = new RestRequest(Method.POST);
                    request.AddHeader("Content-Type", "application/json");
                    request.AddParameter("application/json", "{\r\n    \"EncryptedString\":\"" + strEncriptData + "\"\r\n}", ParameterType.RequestBody);
                    IRestResponse response = client.Execute(request);
                        strResult = response.StatusCode.ToString();
            
                    if(response.StatusCode == HttpStatusCode.MovedPermanently)
                     {
                         string strResponseLocationurl = (string)response.Headers
                                            .Where(x => x.Name == "Location")
                                            .Select(x => x.Value)
                                            .FirstOrDefault();
                         Util.LogRequestResponse("EabakaryService", "RedirectionUrl", strResponseLocationurl);
                         Response.Redirect(strResponseLocationurl);
            
                     }
                     else
                     {
                         Util.LogRequestResponse("EabakaryService", "StatusCode", strResult.ToString());
                     }
            
                   
                }
                else
                {
                        strEncriptData = EXCISE();
                    var client = new RestClient(ConfigurationManager.AppSettings["EXCISEGNSREDIRECTIONURL"].ToString());
                    client.FollowRedirects = false;
                     Util.LogRequestResponse("EabakaryService", "Url :-", "Url :-" + ConfigurationManager.AppSettings["EXCISEGNSREDIRECTIONURL"].ToString());
                     client.Timeout = -1;
                    var request = new RestRequest(Method.POST);
                    request.AddHeader("Content-Type", "application/json");
                    request.AddParameter("application/json", "{\r\n    \"EncryptedString\":\"" + strEncriptData + "\"\r\n}", ParameterType.RequestBody);
                    IRestResponse response = client.Execute(request);
                        strResult = response.StatusCode.ToString();
            
                    if (response.StatusCode == HttpStatusCode.MovedPermanently)
                    {
                        string strResponseLocationurl = (string)response.Headers
                                           .Where(x => x.Name == "Location")
                                           .Select(x => x.Value)
                                           .FirstOrDefault();
                        Util.LogRequestResponse("EabakaryService", "RedirectionUrl", strResponseLocationurl);
                        Response.Redirect(strResponseLocationurl);
            
                    }
                    else
                    {
                        Util.LogRequestResponse("EabakaryService", "StatusCode", strResult.ToString());
                    }
            
            
            
                }
            }
            else if (str_FormId == "69") // OSBC Service
            {
                strEncriptData = OSBC();
                Util.LogRequestResponse("ExciseServiceCall69", "QuerystringData :-", strEncriptData);
                Response.Redirect(ConfigurationManager.AppSettings["OSBCREDIRECTIONURL"].ToString() + "?encData=" + strEncriptData + "");
            }
            else if (str_FormId == "73") // Mobile tower Service
            {
                
                strEncriptData = EIT();
               
                Util.LogRequestResponse("MobileTower", "Encriptiondata", strEncriptData);



                #region For allow https from http url this below part need to add

                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12 | SecurityProtocolType.Ssl3;
                ServicePointManager.SecurityProtocol = (SecurityProtocolType)768 | (SecurityProtocolType)3072;

                #endregion
                

                Util.LogRequestResponse("MobileTower", "EITEncriptonUrl", ConfigurationManager.AppSettings["EitEncryptionUrl"].ToString());
                var options = new RestClient(ConfigurationManager.AppSettings["EitEncryptionUrl"].ToString())
                {
                    Timeout = -1
                };
                var client = new RestClient(options.BaseUrl);
                var request = new RestRequest("?" + strEncriptData+"", Method.GET);
                IRestResponse response =  client.Execute(request);

                Util.LogRequestResponse("MobileTower", "StatusCode", response.StatusCode.ToString());
                Util.LogRequestResponse("MobileTower", "ResponseContent", response.Content.ToString());


                string responseDATA = response.Content;


                if (response.StatusCode == HttpStatusCode.OK)
                {
                    string JSON = response.Content;
                    dynamic data = JObject.Parse(JSON);
                    Util.LogRequestResponse("FireService", "ResponsFromFireservice", JSON);
                   
                    Boolean status = Convert.ToBoolean( data["success"]);
                    if (status)
                    {
                        string strEncryptData = Convert.ToString(data["encryptData"]);
                      
                        string RedirectionUrl = ConfigurationManager.AppSettings["EitRedirectionUrl"].ToString() + strEncryptData.ToString();
                        Util.LogRequestResponse("MobileTower", "RedirectUrl", RedirectionUrl);
                       
                        Response.Redirect(RedirectionUrl, true);
                       

                    }


                }


            }
            else if (str_FormId == "74") // DG SET INSTALLATION
            {
                //  Response.Redirect(ConfigurationManager.AppSettings["DGSETREDIRECTIONURL"].ToString());

                //string TokenURL = "https://serviceonline.gov.in";

                //string options = new RestClient(TokenURL);

                //var client = new RestClient(options);
                //var request = new RestRequest("/configure/authorisation", Method.POST);
                //request.AddHeader("client_id", "34126");
                //request.AddHeader("Content-Type", "application/json");
                //request.AddHeader("Cookie", "JSESSIONID=48366DEBBB34DE32AC27C68A38B83F7F");
                //var body = @"{""username"":""cctns"",""password"":""Test@123""}";
                //request.AddBody(body, DataFormat.Json);
                //RestResponse response = await client.ExecuteAsync(request);
                //Console.WriteLine(response.Content);


                #region For allow https from http url this below part need to add

                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12 | SecurityProtocolType.Ssl3;
                ServicePointManager.SecurityProtocol = (SecurityProtocolType)768 | (SecurityProtocolType)3072;

                #endregion


                //var client = new RestClient("https://serviceonline.gov.in")
                //{
                //    Timeout = -1
                //};

                //var request = new RestRequest("/configure/authorisation", Method.POST);
                //request.AddHeader("client_id", "34126");
                //request.AddHeader("Content-Type", "application/json");
                //request.AddHeader("Cookie", "JSESSIONID=48366DEBBB34DE32AC27C68A38B83F7F");
                //var body = @"{""username"":""cctns"",""password"":""Test@123""}";
                //request.AddBody(body);
                //IRestResponse response = client.Execute(request);
                //string statuscode = response.StatusCode.ToString();
                //string strcontent = response.Content;
                //Console.WriteLine(response.Content);




                var options = new RestClient("https://serviceonline.gov.in/configure/authorisation");
                options.Timeout = -1;
                
                var request = new RestRequest(Method.POST);
                request.AddHeader("client_id", "34126");
                request.AddHeader("Content-Type", "application/json");
                request.AddHeader("Cookie", "JSESSIONID=1D8BD892B469111EC266B2050D0AB0EA");
                var body = @"{""username"":""cctns"",""password"":""Test@123""}";
               
                request.AddParameter("application/json", body, ParameterType.RequestBody);
               
                IRestResponse response = options.Execute(request);
                string statuscode = response.StatusCode.ToString();
                string strcontent = response.Content;
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    string JSON = response.Content;
                    dynamic data = JObject.Parse(JSON);
                    Util.LogRequestResponse("DGSETINSTAL", "ResponsFromDGsetAPI", JSON);
                   
                    int Status_code = Convert.ToInt32(data["status_code"]);

                    if (Status_code == 200)
                    {
                        string authToken = Convert.ToString(data["token"]);


                    }
                }

                   







            }
            else if (str_FormId == "16") // New Power Connection Service by Mo-Biduyt servic API
            {
                strEncriptData = ENERGY();
                Util.LogRequestResponse("EnergyService", "Encriptiondata", strEncriptData);
                #region For allow https from http url this below part need to add
            
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12 |     SecurityProtocolType.Ssl3;
                ServicePointManager.SecurityProtocol = (SecurityProtocolType)768 | (SecurityProtocolType)3072;
            
                #endregion
                string TokenURL = ConfigurationManager.AppSettings["MoBiduytTokenGenerationUrl"].ToString();
                 Util.LogRequestResponse("EnergyService", "TokenURL", TokenURL);
                var Client = new RestClient(TokenURL);
                Client.Timeout = -1;
                var Request = new RestRequest(Method.POST);
                Request.AddHeader("Content-Type", "application/json");
                Request.AddHeader("Authorization", "Basic R29Td2lmdC01Mzc0ODI5NDU0NzozMzYyNzc4OTI4");
                Request.AddHeader("Cookie", "ASP.NET_SessionId=rq2ca2ux1rsp3e1vjyphow3x");
            
                Request.AddParameter("application/json", strEncriptData, ParameterType.RequestBody);
                IRestResponse EncriptionResponse = Client.Execute(Request);
                Util.LogRequestResponse("EnergyService", "TokenStatusCode", EncriptionResponse.StatusCode.ToString());
                if (EncriptionResponse.StatusCode == HttpStatusCode.OK)
                {
                    var strResponseContent = EncriptionResponse.Content.ToString();
                    Util.LogRequestResponse("EnergyService", "Token", strResponseContent);
                    if (strResponseContent != "")
                    {
                        ///Get the access decrypted value.
                        string statusEncriptedDescription = JsonConvert.DeserializeObject<Dictionary<string, object>>(EncriptionResponse.Content)    ["statusDescription"].ToString();
                        Util.LogRequestResponse("EnergyService", "TokenDeserializeData", statusEncriptedDescription);
                        string RedirectionUrl = ConfigurationManager.AppSettings["MoBiduytRedirectionUrl"].ToString() + statusEncriptedDescription;
                       Util.LogRequestResponse("EnergyService", "RedirectUrl", RedirectionUrl);
                        Response.Redirect(RedirectionUrl,true);
            
                    }
                }
            
            
            
                
            
            }
            else if (str_FormId == "52") ///Trade Licenece Service
            {
                strEncriptData = TRADELICENSE();
                Util.LogRequestResponse("TradeLicenece", "Encriptiondata", strEncriptData);
                #region For allow https from http url this below part need to add

                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12 | SecurityProtocolType.Ssl3;
                ServicePointManager.SecurityProtocol = (SecurityProtocolType)768 | (SecurityProtocolType)3072;

                #endregion

                string strTradeLicenseEncryptUrl = ConfigurationManager.AppSettings["TradeLicenseEncryptUrl"].ToString();
                Util.LogRequestResponse("TradeLicenece", "TradeLicenseEncryptUrl", strTradeLicenseEncryptUrl);
                var Client = new RestClient(strTradeLicenseEncryptUrl);
                Client.Timeout = -1;
                var Request = new RestRequest(Method.POST);
                Request.AddHeader("Content-Type", "application/json");
                Request.AddParameter("application/json", strEncriptData, ParameterType.RequestBody);
                IRestResponse dataResponse = Client.Execute(Request);
                Util.LogRequestResponse("TradeLicenece", "StatusCode", dataResponse.StatusCode.ToString());
                Util.LogRequestResponse("TradeLicenece", "ResponseContent", dataResponse.Content.ToString());
                if (dataResponse.StatusCode == HttpStatusCode.OK)
                {
                    string RedirectionUrl = ConfigurationManager.AppSettings["TradeLicenseRedirectionUrl"].ToString() + dataResponse.Content.ToString();
                    Util.LogRequestResponse("TradeLicenece", "RedirectUrl", RedirectionUrl);
                    Response.Redirect(RedirectionUrl, true);

                }

            }


        }
        catch(Exception ex)
        {
            Util.LogError(ex, "ServiceRedirect");
        }
    }

    protected void BtnNo_Click(object sender, EventArgs e)
    {
        lblMessage.Text = "";
        ServiceModalPopup.Hide();
        Response.Redirect("ServiceInstructionExternal.aspx?FormId=" + str_FormId + "&ProposalNo=" + str_ProposalNo + "&Amount=" + str_Amount + "&ServiceType=" + Int_ServiceType + "&ReqMode=" + str_RequestMode);
    }

    private string BPAS()
    {
        DataTable dt = new DataTable();
        string EncryptValue = "";
        try
        {
            SqlCommand cmd = new SqlCommand();
            if (conn.State == ConnectionState.Closed)
            {
                conn.Open();
            }
            try
            {
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_BPAS_SERVICE_DISPLAY";
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@INT_INVESTOR_ID", Convert.ToInt32(Session["InvestorId"].ToString()));
                cmd.Parameters.AddWithValue("@VCH_ACTION", "INDUSTRYINFO");
                cmd.Parameters.AddWithValue("@VCH_APPLICATION_UNQ_KEY", "");
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
            }
            catch (Exception ex)
            {
                Util.LogError(ex, "BPASSP");
            }
            finally
            {
                
                conn.Close();
            }
            string output = objSvc.ExternalServiceData("GA", Convert.ToInt32(str_FormId), str_ProposalNo, Convert.ToInt32(Session["InvestorId"]), Session["PAN"].ToString());
            if (output != "")
            {
                if (dt.Rows.Count > 0)
                {
                    string AppBmcUrl = ConfigurationManager.AppSettings["BPASCHECKSTATUSURL"].ToString();
                    var client = new RestClient("" + AppBmcUrl + "");
                    var request = new RestRequest(Method.POST);
                    request.AddHeader("postman-token", "487391e8-90a4-0edf-d80a-85927ba52b8f");
                    request.AddHeader("cache-control", "no-cache");
                    request.AddHeader("authorization", "Basic YmJzcm9uZUAyMDE4OlZLY0VoNFduQk9SVXAyY21GUmQzWTBSell4UVcxV1I=");
                    request.AddHeader("content-type", "application/json");
                    request.AddParameter("application/json", "{\"action\":\"encrypt\",\"encString\":\"" + dt.Rows[0]["VCH_CONTACT_FIRSTNAME"].ToString() + "~::~" + dt.Rows[0]["VCH_CONTACT_MIDDLENAME"].ToString() + "~::~" + dt.Rows[0]["VCH_CONTACT_LASTNAME"].ToString() + "~::~" + dt.Rows[0]["VCH_OFF_MOBILE"].ToString() + "~::~" + dt.Rows[0]["VCH_EMAIL"].ToString() + "~::~" + dt.Rows[0]["VCH_INV_USERID"].ToString() + "~::~" + output + "~::~" + ConfigurationManager.AppSettings["GOSWIFTDRAFTURL"].ToString() + "~::~" + "1" + "\"}", ParameterType.RequestBody);
                    IRestResponse response = client.Execute(request);
                    string JSON = response.Content;
                    var dict = new JavaScriptSerializer().Deserialize<Dictionary<string, object>>(JSON);
                    EncryptValue = dict["result"].ToString();
                }
                else
                {
                    string AppBmcUrl = ConfigurationManager.AppSettings["BPASCHECKSTATUSURL"].ToString();
                    var client = new RestClient("" + AppBmcUrl + "");
                    var request = new RestRequest(Method.POST);
                    request.AddHeader("postman-token", "487391e8-90a4-0edf-d80a-85927ba52b8f");
                    request.AddHeader("cache-control", "no-cache");
                    request.AddHeader("authorization", "Basic YmJzcm9uZUAyMDE4OlZLY0VoNFduQk9SVXAyY21GUmQzWTBSell4UVcxV1I=");
                    request.AddHeader("content-type", "application/json");
                    request.AddParameter("application/json", "{\"action\":\"encrypt\",\"encString\":\"" + "NA" + "~::~" + "NA" + "~::~" + "NA" + "~::~" + "NA" + "~::~" + "NA" + "~::~" + "NA" + "~::~" + output + "~::~" + ConfigurationManager.AppSettings["GOSWIFTDRAFTURL"].ToString() + "~::~" + "1" + "\"}", ParameterType.RequestBody);
                    IRestResponse response = client.Execute(request);
                    string JSON = response.Content;
                    var dict = new JavaScriptSerializer().Deserialize<Dictionary<string, object>>(JSON);
                    EncryptValue = dict["result"].ToString();
                }
            }
        }
        catch (Exception ex)
        {
            Util.LogError(ex, "BPASENC");
        }
        return EncryptValue;
    }
    private string GOIPAS()
    {
        string EncryptValue = "";
        DataTable dt = new DataTable();
        try
        {
            SqlCommand cmd = new SqlCommand();
            if (conn.State == ConnectionState.Closed)
            {
                conn.Open();
            }
            try
            {
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_GOIPAS_SERVICE_DISPLAY";
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@INT_INVESTOR_ID", Convert.ToInt32(Session["InvestorId"].ToString()));
                cmd.Parameters.AddWithValue("@VCH_ACTION", "INDUSTRYINFO");
                cmd.Parameters.AddWithValue("@VCH_APPLICATION_UNQ_KEY", "");
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
            }
            catch (Exception ex)
            {
                Util.LogError(ex, "GOIPASSP");
            }
            finally
            {
               
                conn.Close();
            }
            string output = objSvc.ExternalServiceData("GA", Convert.ToInt32(str_FormId), str_ProposalNo, Convert.ToInt32(Session["InvestorId"]), Session["PAN"].ToString());
            if (output != "")
            {
                if (dt.Rows.Count > 0)
                {
                    EncryptDecryptQueryString obj = new EncryptDecryptQueryString();
                    string Data = "" + dt.Rows[0]["VCH_PAN"].ToString() + "&" + dt.Rows[0]["VCH_EMAIL"].ToString() + "&" + dt.Rows[0]["VCH_UNIQUEID"].ToString() + "&" + dt.Rows[0]["INT_DISTRICT"].ToString() + "&" + output + "&" + ConfigurationManager.AppSettings["GOSWIFTDRAFTURL"].ToString() + "";
                    EncryptValue = obj.Encrypt(Data, "m8s3e3k5");
                }
                else
                {
                    EncryptValue = "";
                }
            }
        }
        catch (Exception ex)
        {
            Util.LogError(ex, "GOIPASENC");
        }
        return EncryptValue;
    }
    private string PAReSHRAM()
    {
        string EncryptValue = "";
        DataTable dt = new DataTable();
        try
        {
            SqlCommand cmd = new SqlCommand();
            if (conn.State == ConnectionState.Closed)
            {
                conn.Open();
            }
            try
            {
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_PAReSHRAM_SERVICE_DISPLAY";
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@INT_INVESTOR_ID", Convert.ToInt32(Session["InvestorId"].ToString()));
                cmd.Parameters.AddWithValue("@VCH_ACTION", "INDUSTRYINFO");
                cmd.Parameters.AddWithValue("@VCH_APPLICATION_UNQ_KEY", "");
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
            }
            catch (Exception ex)
            {
                Util.LogError(ex, "PAReSHRAMSP");
                
            }
            finally
            {
                
                conn.Close();
            }
            string output = objSvc.ExternalServiceData("GA", Convert.ToInt32(str_FormId), str_ProposalNo, Convert.ToInt32(Session["InvestorId"]), Session["PAN"].ToString());
            if (output != "")
            {
                if (dt.Rows.Count > 0)
                {
                    string Industry_name = Uri.EscapeDataString(dt.Rows[0]["VCH_INV_NAME"].ToString());
                    EncryptValue = "appln_id=" + output + "&service_code=" + str_FormId.ToString() + "&pan=" + dt.Rows[0]["VCH_PAN"].ToString() + "&name=" + dt.Rows[0]["VCH_CONTACT_FIRSTNAME"].ToString() + "&mobile_number=" + dt.Rows[0]["VCH_OFF_MOBILE"].ToString() + "&email=" + dt.Rows[0]["VCH_EMAIL"].ToString() + "&est_name=" + Industry_name;
                }
                else
                {
                    EncryptValue = "appln_id=" + output + "&service_code=" + str_FormId.ToString() + "&pan=" + "" + "&name=" + "" + "&mobile_number=" + "" + "&email=" + "" + "&est_name=''";
                }
            }
        }
        catch (Exception ex)
        {
            Util.LogError(ex, "PAReSHRAMENC");
        }
        return EncryptValue;
    }

    /// <summary>
    /// this method used create JSON data for apply new power connection by Mo-Biduyt api
    /// </summary>

    private string ENERGY()
    {
        string EncryptValue = "";
        DataTable dt = new DataTable();
        try
        {
            SqlCommand cmd = new SqlCommand();
            if (conn.State == ConnectionState.Closed)
            {
                conn.Open();
            }

            cmd.Connection = conn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "USP_Energy_SERVICE_DISPLAY";
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@INT_INVESTOR_ID", Convert.ToInt32(Session["InvestorId"].ToString()));
            cmd.Parameters.AddWithValue("@VCH_ACTION", "INDUSTRYINFO");
            cmd.Parameters.AddWithValue("@VCH_APPLICATION_UNQ_KEY", "");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);


            string output = objSvc.ExternalServiceData("GA", Convert.ToInt32(str_FormId), str_ProposalNo, Convert.ToInt32(Session["InvestorId"]), Session["PAN"].ToString());
            if (output != "")
            {
                if (dt.Rows.Count > 0)
                {

                    EncryptValue = "{\"serviceId\":\"" + str_FormId.ToString() + "\",\"name\":\"" + dt.Rows[0]["VCH_CONTACT_FIRSTNAME"].ToString() + "\",\"pan\":\"" + dt.Rows[0]["VCH_PAN"].ToString() + "\",\"email\":\"" + dt.Rows[0]["VCH_EMAIL"].ToString() + "\",\"mobile\":\"" + dt.Rows[0]["VCH_OFF_MOBILE"].ToString() + "\",\"goSwiftApplicationId\":\"" + output + "\"}";

                }
                else
                {
                    EncryptValue = "{\"serviceid\":\"\",\"goSwiftApplicationId\":\"\",\"name\":\"\",\"pan\":\"\",\"email\":\"\",\"mobile\":\"\"}";

                }
            }
        }
        catch (Exception ex)
        {
            Util.LogError(ex, "Energy");
        }
        return EncryptValue;
    }

    private string DRUG()
    {
        string strEncryptValue = "";
        DataTable dt = new DataTable();
        try
        {
            SqlCommand cmd = new SqlCommand();
            if (conn.State == ConnectionState.Closed)
            {
                conn.Open();
            }
            cmd.Connection = conn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "USP_DRUG_SERVICE_DISPLAY";
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@INT_INVESTOR_ID", Convert.ToInt32(Session["InvestorId"].ToString()));
            cmd.Parameters.AddWithValue("@VCH_ACTION", "INDUSTRYINFO");
            cmd.Parameters.AddWithValue("@VCH_APPLICATION_UNQ_KEY", "");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            string output = objSvc.ExternalServiceData("GA", Convert.ToInt32(str_FormId), str_ProposalNo, Convert.ToInt32(Session["InvestorId"]), Session["PAN"].ToString());
            if (output != "")
            {
                if (dt.Rows.Count > 0)
                {
                    strEncryptValue = "{\"pan_no\":\"" + dt.Rows[0]["VCH_PAN"].ToString() + "\",\"mobile_no\":\"" + dt.Rows[0]["VCH_OFF_MOBILE"].ToString() + "\",\"email\":\"" + dt.Rows[0]["VCH_EMAIL"].ToString() + "\",\"organization_name\":\"" + dt.Rows[0]["VCH_INV_NAME"].ToString() + "\",\"referene_id\":\"" + output.ToString() + "\",\"dept_id\":\"" + str_FormId.ToString() + "\"}";
                }
                else
                {
                    strEncryptValue = "{\"pan_no\":\"\",\"mobile_no\":\"\",\"email\":\"\",\"organization_name\":\"\",\"referene_id\":\"\",\"dept_id\":\"\"}";
                }
            }
        }
        catch (Exception ex)
        {
            Util.LogError(ex, "Drugs");
        }
        return strEncryptValue;
    }

    ///Trade Licenece Service
    private string TRADELICENSE()
    {
        string strEncryptValue = "";
        DataTable dt = new DataTable();
        try
        {
            SqlCommand cmd = new SqlCommand();
            if (conn.State == ConnectionState.Closed)
            {
                conn.Open();
            }
            cmd.Connection = conn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "USP_TRADE_LICENSE_SERVICE_DISPLAY";
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@INT_INVESTOR_ID", Convert.ToInt32(Session["InvestorId"].ToString()));
            cmd.Parameters.AddWithValue("@VCH_ACTION", "INDUSTRYINFO");
            cmd.Parameters.AddWithValue("@VCH_APPLICATION_UNQ_KEY", "");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            string strTradeLicenseSecurityKey = ConfigurationManager.AppSettings["TradeLicenseSecurityKey"].ToString();
            string output = objSvc.ExternalServiceData("GA", Convert.ToInt32(str_FormId), str_ProposalNo, Convert.ToInt32(Session["InvestorId"]), Session["PAN"].ToString());
            if (output != "")
            {
                if (dt.Rows.Count > 0)
                {
                    strEncryptValue = "{\"RequestInfo\": {\"apiId\": \"Rainmaker\",\"ver\": \".01\",\"action\": \"\",\"did\": \"1\",\"key\": \"\",\"msgId\": \"20170310130900|en_IN\",\"requesterId\": \"\"},\r\n\"GoSwiftInput\": {\"tenantId\": \"od\",\"applicationNo\": \"" + output.ToString() + "\",\"serviceId\": \"" + str_FormId.ToString() + "\",\"mobileNo\": \"" + dt.Rows[0]["VCH_OFF_MOBILE"].ToString() + "\",\"emailId\":\"" + dt.Rows[0]["VCH_EMAIL"].ToString() + "\",\r\n\"companyName\": \"" + dt.Rows[0]["VCH_INV_NAME"].ToString() + "\",\"name\":\"" + dt.Rows[0]["VCH_CONTACT_FIRSTNAME"].ToString() + "\",\"securityToken\":\"" + strTradeLicenseSecurityKey.ToString() + "\"}}";
                }
                else
                {
                    strEncryptValue = "{\"pan_no\":\"\",\"mobile_no\":\"\",\"email\":\"\",\"organization_name\":\"\",\"referene_id\":\"\",\"dept_id\":\"\"}";
                }
            }
        }
        catch (Exception ex)
        {
            Util.LogError(ex, "TradeLicense");
        }
        return strEncryptValue;
    }

    private string FOREST()
    {
        string EncryptValue = "";
        DataTable dt = new DataTable();
        try
        {
            SqlCommand cmd = new SqlCommand();
            if (conn.State == ConnectionState.Closed)
            {
                conn.Open();
            }
            try
            {
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_FOREST_SERVICE_DISPLAY";
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@INT_INVESTOR_ID", Convert.ToInt32(Session["InvestorId"].ToString()));
                cmd.Parameters.AddWithValue("@VCH_ACTION", "INDUSTRYINFO");
                cmd.Parameters.AddWithValue("@VCH_APPLICATION_UNQ_KEY", "");
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
            }
            catch (Exception ex)
            {
                Util.LogError(ex, "Forest");
               
            }
            finally
            {
               
                conn.Close();
            }
            string output = objSvc.ExternalServiceData("GA", Convert.ToInt32(str_FormId), str_ProposalNo, Convert.ToInt32(Session["InvestorId"]), Session["PAN"].ToString());
            if (output != "")
            {
                if (dt.Rows.Count > 0)
                {
                    string Industry_name = Uri.EscapeDataString(dt.Rows[0]["VCH_INV_NAME"].ToString());
                    EncryptValue = "appln_id=" + output + "&service_code=" + str_FormId.ToString() + "&pan=" + dt.Rows[0]["VCH_PAN"].ToString() + "&name=" + dt.Rows[0]["VCH_CONTACT_FIRSTNAME"].ToString() + "&mobile_number=" + dt.Rows[0]["VCH_OFF_MOBILE"].ToString() + "&email=" + dt.Rows[0]["VCH_EMAIL"].ToString() + "&est_name=" + Industry_name+ "&UserId="+ Session["InvestorId"].ToString();
                }
                else
                {
                    EncryptValue = "appln_id=" + output + "&service_code=" + str_FormId.ToString() + "&pan=" + "" + "&name=" + "" + "&mobile_number=" + "" + "&email=" + "" + "&est_name=''"+ "&UserId=''";
                }
            }
        }
        catch (Exception ex)
        {
            Util.LogError(ex, "Forest");
        }
        return EncryptValue;
    }

    private string FIRE()
    {
        string EncryptValue = "";
        DataTable dt = new DataTable();
        try
        {
            SqlCommand cmd = new SqlCommand();
            if (conn.State == ConnectionState.Closed)
            {
                conn.Open();
            }
            try
            {
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_FIRE_SERVICE_DISPLAY";
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@INT_INVESTOR_ID", Convert.ToInt32(Session["InvestorId"].ToString()));
                cmd.Parameters.AddWithValue("@VCH_ACTION", "INDUSTRYINFO");
                cmd.Parameters.AddWithValue("@VCH_APPLICATION_UNQ_KEY", "");
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
            }
            catch (Exception ex)
            {
                Util.LogError(ex, "FIRESP");
            }
            finally
            {
               
                conn.Close();
            }
            string output = objSvc.ExternalServiceData("GA", Convert.ToInt32(str_FormId), str_ProposalNo, Convert.ToInt32(Session["InvestorId"]), Session["PAN"].ToString());
            if (output != "")
            {
                if (dt.Rows.Count > 0)
                {
                    #region For allow https from http url this below part need to add

                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12 | SecurityProtocolType.Ssl3;
                    ServicePointManager.SecurityProtocol = (SecurityProtocolType)768 | (SecurityProtocolType)3072;

                    #endregion
                    var client = new RestClient("" + ConfigurationManager.AppSettings["FIRECHECKSTATUSURL"].ToString() + "?name='" + dt.Rows[0]["VCH_INV_NAME"].ToString() + "'&email='" + dt.Rows[0]["VCH_EMAIL"].ToString() + "'&mobile='" + dt.Rows[0]["VCH_OFF_MOBILE"].ToString() + "'&serviceId=" + str_FormId + "&applicationId='" + output + "'&mode=" + 1 + "&source='GOSWIFT'&returnUrl='" + ConfigurationManager.AppSettings["GOSWIFTDRAFTURL"].ToString() + "'");

                    Util.LogRequestResponse("FireService", "Requeststring :-", "Url :-"+ ConfigurationManager.AppSettings["FIRECHECKSTATUSURL"].ToString()+ " name=" + dt.Rows[0]["VCH_INV_NAME"].ToString() + " &email="+ dt.Rows[0]["VCH_EMAIL"].ToString()+ " &mobile=" + dt.Rows[0]["VCH_OFF_MOBILE"].ToString() + " &serviceId="+ str_FormId+ " &applicationId="+ output+ " &returnUrl="+ ConfigurationManager.AppSettings["GOSWIFTDRAFTURL"].ToString());

                    client.Timeout = -1;
                    var request = new RestRequest(Method.GET);
                    request.AlwaysMultipartFormData = true;
                    IRestResponse response = client.Execute(request);
                    Util.LogRequestResponse("FireService", "ResponsStatusCodeFromFireservice", response.StatusCode.ToString());
                    string JSON = response.Content;
                    dynamic data = JObject.Parse(JSON);
                    Util.LogRequestResponse("FireService", "ResponsFromFireservice", JSON);
                   // var dict = new JavaScriptSerializer().Deserialize<Dictionary<string, object>>(data);


                   
                    EncryptValue = data["result"].ToString();
                    Util.LogRequestResponse("FireService", "EncriptedResponcData", "EncriptedResponcData :-" + data["result"].ToString());
                }
                else
                {
                    #region For allow https from http url this below part need to add

                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12 | SecurityProtocolType.Ssl3;
                    ServicePointManager.SecurityProtocol = (SecurityProtocolType)768 | (SecurityProtocolType)3072;

                    #endregion
                    var client = new RestClient("" + ConfigurationManager.AppSettings["FIRECHECKSTATUSURL"].ToString() + "?name=''&email=''&mobile=''&serviceId=" + str_FormId + "&applicationId='" + output + "'&mode=" + 1 + "&source='GOSWIFT'&returnUrl='" + ConfigurationManager.AppSettings["GOSWIFTDRAFTURL"].ToString() + "'");

                    Util.LogRequestResponse("FireService", "Requeststring :-", "Url :-" + ConfigurationManager.AppSettings["FIRECHECKSTATUSURL"].ToString() + " &serviceId=" + str_FormId + " &applicationId=" + output + " &returnUrl=" + ConfigurationManager.AppSettings["GOSWIFTDRAFTURL"].ToString());

                    client.Timeout = -1;
                    var request = new RestRequest(Method.GET);
                    request.AlwaysMultipartFormData = true;
                    IRestResponse response = client.Execute(request);
                    Util.LogRequestResponse("FireService", "ResponsStatusCodeFromFireservice", response.StatusCode.ToString());
                    string JSON = response.Content;
                    dynamic data = JObject.Parse(JSON);
                    Util.LogRequestResponse("FireService", "ResponsFromFireservice", JSON);
                   // var dict = new JavaScriptSerializer().Deserialize<Dictionary<string, object>>(JSON);
                   
                    EncryptValue = data["result"].ToString();
                    Util.LogRequestResponse("FireService", "EncriptedResponcData", "EncriptedResponcData :-"+ data["result"].ToString());
                }
            }
        }
        catch (Exception ex)
        {
            Util.LogError(ex, "FIREENC");
        }
        return EncryptValue;
    }

   
    private string EXCISE()
    {
        string strplaintext = "";
        string EncryptValue = "";
        string strSuppliedKey = "?åLˆ'KX¾p ;™¶%M8º}ÌqE-ƒU§©	;±½";
        byte[] key = { };
        key = Encoding.ASCII.GetBytes(strSuppliedKey);
        DataTable dt = new DataTable();
        try
        {
            SqlCommand cmd = new SqlCommand();
            if (conn.State == ConnectionState.Closed)
            {
                conn.Open();
            }
            try
            {
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_EXCISE_SERVICE_DISPLAY";
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@INT_INVESTOR_ID", Convert.ToInt32(Session["InvestorId"].ToString()));
                cmd.Parameters.AddWithValue("@VCH_ACTION", "INDUSTRYINFO");
                cmd.Parameters.AddWithValue("@VCH_APPLICATION_UNQ_KEY", "");
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
            }
            catch (Exception ex)
            {
                Util.LogError(ex, "EXCISESP");
            }
            finally
            {
                
                conn.Close();
            }
            string output = objSvc.ExternalServiceData("GA", Convert.ToInt32(str_FormId), str_ProposalNo, Convert.ToInt32(Session["InvestorId"]), Session["PAN"].ToString());
            if (output != "")
            {
                if (dt.Rows.Count > 0)
                {
                     strplaintext = "" + dt.Rows[0]["VCH_INV_NAME"].ToString() + "|" + dt.Rows[0]["VCH_OFF_MOBILE"].ToString() + "|" + str_FormId + "|" + output + "|1";

                    Util.LogRequestResponse("EabakaryService", "GoswiftInputDataInput :-", strplaintext);
                    //strplaintext = "" + "GoiPlus" + "|" + "9778065403" + "|" + "67" + "|" + "EX20240619677294" + "|1";
                    EncryptValue = ExciseEncryptAlgorthim(strplaintext, key);
                    Util.LogRequestResponse("EabakaryService", "GoswiftInputDataEncriptvalue :-", EncryptValue);
                }
                else
                {
                    strplaintext = "NA|NA|NA|NA|1";
                    EncryptValue = ExciseEncryptAlgorthim(strplaintext, key);
                }
            }
        }
        catch (Exception ex)
        {
            Util.LogError(ex, "EXCISEENC");
        }
        return EncryptValue;
    }
    public static string ExciseEncryptAlgorthim(string plainText, byte[] Key)
    {
        if (plainText == null || plainText.Length <= 0)
            throw new ArgumentNullException("plainText");
        if (Key == null || Key.Length <= 0)
            throw new ArgumentNullException("Key");
        byte[] encrypted;
        string base64encrypted;
        using (AesManaged aesAlg = new AesManaged())
        {
            aesAlg.Key = Key;
            aesAlg.Mode = CipherMode.ECB;
            ICryptoTransform encryptor = aesAlg.CreateEncryptor(aesAlg.Key, aesAlg.IV);
            using (MemoryStream msEncrypt = new MemoryStream())
            {
                using (CryptoStream csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                {
                    using (StreamWriter swEncrypt = new StreamWriter(csEncrypt))
                    {
                        swEncrypt.Write(plainText);
                    }
                    encrypted = msEncrypt.ToArray();
                }
            }
        }
        base64encrypted = Convert.ToBase64String(encrypted, 0, encrypted.Length);
        return base64encrypted.Replace("/", "-");
    }

    // Mobile tower service
    public string EIT()
    {
        string EncryptValue = "";
        DataTable dt = new DataTable();
        try
        {
            SqlCommand cmd = new SqlCommand();
            if (conn.State == ConnectionState.Closed)
            {
                conn.Open();
            }
            try
            {
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_EIT_SERVICE_DISPLAY";
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@INT_INVESTOR_ID", Convert.ToInt32(Session["InvestorId"].ToString()));
                cmd.Parameters.AddWithValue("@VCH_ACTION", "INDUSTRYINFO");
                cmd.Parameters.AddWithValue("@VCH_APPLICATION_UNQ_KEY", "");
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
            }
            catch (Exception ex)
            {
                Util.LogError(ex, "EITSP");
                
            }
            finally
            {
                
                conn.Close();
            }
            string output = objSvc.ExternalServiceData("GA", Convert.ToInt32(str_FormId), str_ProposalNo, Convert.ToInt32(Session["InvestorId"]), Session["PAN"].ToString());
            if (output != "")
            {
                if (dt.Rows.Count > 0)
                {
                    //  EncryptValue = "authorised_person=" + dt.Rows[0]["VCH_CONTACT_FIRSTNAME"].ToString() + "&phone_number=" + dt.Rows[0]["VCH_OFF_MOBILE"].ToString() + "&email=" + dt.Rows[0]["VCH_EMAIL"].ToString() + "&district=" + dt.Rows[0]["vchDistrictName"].ToString() + "&uniqid=" + output + "&ServiceId=" + str_FormId + "";
                    EncryptValue = "AppNo=" + output.ToString() + "&ServiceId=" + str_FormId.ToString() + "&MobileNo=" + dt.Rows[0]["VCH_OFF_MOBILE"].ToString() + "&EmailId="+ dt.Rows[0]["VCH_EMAIL"].ToString() + "&CompanyName=" + dt.Rows[0]["VCH_INV_NAME"].ToString()+"";
                   
                }
                else
                {
                    EncryptValue = "authorised_person=" + "" + "&phone_number=" + "" + "&email=" + "" + "&district=" + "" + "&uniqid=" + output + "&ServiceId=" + str_FormId + "";
                }
            }
        }
        catch (Exception ex)
        {
            Util.LogError(ex, "EITENC");
        }
        return EncryptValue;
    }
    private string OSBC()
    {
        string EncryptValue = "";
        DataTable dt = new DataTable();
        ExciseOSBCServiceReference.OSBCSoftSoapClient objEx = new ExciseOSBCServiceReference.OSBCSoftSoapClient();
        ExciseOSBCServiceReference.SupDetails objEntity = new ExciseOSBCServiceReference.SupDetails();
        try
        {
            SqlCommand cmd = new SqlCommand();
            if (conn.State == ConnectionState.Closed)
            {
                conn.Open();
            }
            try
            {
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_OSBC_SERVICE_DISPLAY";
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@INT_INVESTOR_ID", Convert.ToInt32(Session["InvestorId"].ToString()));
                cmd.Parameters.AddWithValue("@VCH_ACTION", "INDUSTRYINFO");
                cmd.Parameters.AddWithValue("@VCH_APPLICATION_UNQ_KEY", "");
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
            }
            catch (Exception ex)
            {
                Util.LogError(ex, "OSBCSP");
            }
            finally
            {
                
                conn.Close();
            }
            string output = objSvc.ExternalServiceData("GA", Convert.ToInt32(str_FormId), str_ProposalNo, Convert.ToInt32(Session["InvestorId"]), Session["PAN"].ToString());
            Util.LogRequestResponse("ExciseServiceCall69", "Output :-", output);
            if (output != "")
            {
                if (dt.Rows.Count > 0)
                {
                    objEntity.Application_No = output;
                    objEntity.GoSwiftUserID = dt.Rows[0]["VCH_INV_USERID"].ToString();
                    objEntity.MobileNo = dt.Rows[0]["VCH_OFF_MOBILE"].ToString(); ;
                    objEntity.Name = dt.Rows[0]["VCH_CONTACT_FIRSTNAME"].ToString();
                    objEntity.Email = dt.Rows[0]["VCH_EMAIL"].ToString();
                    objEntity.Sector_Type = dt.Rows[0]["VCH_SECTOR"].ToString();
                    objEntity.Sector_Subtype = dt.Rows[0]["vchSubSectorName"].ToString();
                    objEntity.ServiceID = str_FormId;
                    objEntity.Source = "GOSWIFT";
                    objEntity.Active_Status = "Yes";
                    objEntity.ReturnURL = "http://203.193.144.114/SWP/Login.aspx";
                    JavaScriptSerializer jsonSerialiser1 = new JavaScriptSerializer();
                    var json1 = jsonSerialiser1.Serialize(objEntity);
                    
                    Util.LogRequestResponse("ExciseServiceCall69", "pushdataforEncription :-", json1);
                    EncryptValue = objEx.AESEncryptForSignUP(objEntity);
                    Util.LogRequestResponse("ExciseServiceCall69", "encriptedvalues :-", EncryptValue);
                }
                else
                {
                    objEntity.Application_No = output;
                    objEntity.GoSwiftUserID = "";
                    objEntity.MobileNo = "";
                    objEntity.Name = "";
                    objEntity.Email = "";
                    objEntity.Sector_Type = "";
                    objEntity.Sector_Subtype = "";
                    objEntity.ServiceID = str_FormId;
                    objEntity.Source = "GOSWIFT";
                    objEntity.Active_Status = "Yes";
                    objEntity.ReturnURL = "http://203.193.144.114/SWP/Login.aspx";
                    EncryptValue = objEx.AESEncryptForSignUP(objEntity);
                    Util.LogRequestResponse("ExciseServiceCall69", "encriptedvalues :-", EncryptValue);
                }
            }
        }
        catch (Exception ex)
        {
            Util.LogError(ex, "OSBCENC");
        }
        return EncryptValue;
    }

    public string DGSET()
    {
        string EncryptValue = "";
        DataTable dt = new DataTable();
        try
        {
            SqlCommand cmd = new SqlCommand();
            if (conn.State == ConnectionState.Closed)
            {
                conn.Open();
            }
            cmd.Connection = conn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "USP_DGSET_SERVICE_DISPLAY";
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@INT_INVESTOR_ID", Convert.ToInt32(Session["InvestorId"].ToString()));
            cmd.Parameters.AddWithValue("@VCH_ACTION", "INDUSTRYINFO");
            cmd.Parameters.AddWithValue("@VCH_APPLICATION_UNQ_KEY", "");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);

            string output = objSvc.ExternalServiceData("GA", Convert.ToInt32(str_FormId), str_ProposalNo, Convert.ToInt32(Session["InvestorId"]), Session["PAN"].ToString());

            if (output != "")
            {
                if (dt.Rows.Count > 0)
                {

                    EncryptValue = "{\"input\":{\"serviceId\":\"909\",\"appForm\":{\"REQUISITION_ID\":\"" + output.ToString() + "\",\"ApplicantName\":\"" + dt.Rows[0]["VCH_CONTACT_FIRSTNAME"].ToString() + "\",\"GoswiftServiceID\":\"" + str_FormId.ToString() + "\",\"MobileNumber\":\"" + dt.Rows[0]["VCH_OFF_MOBILE"].ToString() + "\",\"Email\":\"" + dt.Rows[0]["VCH_EMAIL"].ToString() + "\",\"CompanyName\":\"" + dt.Rows[0]["VCH_INV_NAME"].ToString() + "\"}}}";
                   


                   // strEncryptValue = "{\"RequestInfo\": {\"apiId\": \"Rainmaker\",\"ver\": \".01\",\"action\": \"\",\"did\": \"1\",\"key\": \"\",\"msgId\": \"20170310130900|en_IN\",\"requesterId\": \"\"},\r\n\"GoSwiftInput\": {\"tenantId\": \"od\",\"applicationNo\": \"" + output.ToString() + "\",\"serviceId\": \"" + str_FormId.ToString() + "\",\"mobileNo\": \"" + dt.Rows[0]["VCH_OFF_MOBILE"].ToString() + "\",\"emailId\":\"" + dt.Rows[0]["VCH_EMAIL"].ToString() + "\",\r\n\"companyName\": \"" + dt.Rows[0]["VCH_INV_NAME"].ToString() + "\",\"name\":\"" + dt.Rows[0]["VCH_CONTACT_FIRSTNAME"].ToString() + "\",\"securityToken\":\"" + strTradeLicenseSecurityKey.ToString() + "\"}}";
                }


            
            }

        }
        catch (Exception ex)
        {
            Util.LogError(ex, "DGSET");
        }

        return EncryptValue;
    }
}
