﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Services;
using System.IO;
using BusinessLogicLayer.Proposal;
using EntityLayer.Proposal;
using EntityLayer.Service;
using BusinessLogicLayer.Service;
using System.Configuration;
using System.Data.SqlClient;
using RestSharp;
using System.Web.Script.Serialization;
using System.Text;
using System.Security.Cryptography;
using System.Net;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

public partial class DraftedServices : System.Web.UI.Page
{
    DataTable dtable;
    ServiceBusinessLayer objService = new ServiceBusinessLayer();
    ProposalDet objProposal = new ProposalDet();
    string strRetval = "";
    int intRetVal = 0;
    int dtval = 0;
    int Exdtval = 0;
    SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["AdminAppConnectionProd"].ToString());
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserId"] != null)
            {
                BindGridDraft();
            }
            else
            {
                Response.Redirect("~/Login.aspx");
            }
        }
    }

    #region Member Function
    private void BindGridDraft()
    {
        objProposal = new ProposalDet();
        try
        {
            List<ProposalDet> objProposalList = new List<ProposalDet>();
            ProposalDet objProp = new ProposalDet();
            objProp.strAction = "D";
            objProp.intCreatedBy = Convert.ToInt32(Session["InvestorId"]);

            ///Get All Drafted Applications
            List<ServiceDetails> ServiceDetail = objService.GetAllDraftedApplicationDetails(Session["UserId"].ToString()).ToList();

            ///Filter Internal Services
            List<EntityLayer.Service.ServiceDetails> ObjInternalSvc = ServiceDetail.Where(n => n.str_checkStatus == "0" && n.intStatus==10).ToList() ;
            gvDraftService.DataSource = ObjInternalSvc;
            gvDraftService.DataBind();
            MergeRows(gvDraftService);

            ///Filter External Services
            List<EntityLayer.Service.ServiceDetails> ObjExternalSvc = ServiceDetail.Where(n => n.str_checkStatus == "1" && n.intStatus == 10).ToList();
            gvExDraftService.DataSource = ObjExternalSvc;
            gvExDraftService.DataBind();

            if (ObjInternalSvc.Count > 0)
            {
                icon.Visible = true;
            }
            else
            {
                icon.Visible = false;
            }

            if (ObjExternalSvc.Count > 0)
            {
                Exicon.Visible = true;
            }
            else
            {
                Exicon.Visible = false;
            }

            dtval = ObjInternalSvc.Count;
            Exdtval = ObjExternalSvc.Count;

            DisplayPaging();
            ExDisplayPaging();

            Session["SvcMasterData"] = null;
        }
        catch (Exception ex)
        {
            Util.LogError(ex, "DraftService");
        }
        finally
        {
            objProposal = null;
        }
    }
    #endregion

    protected void gvDraftService_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvDraftService.PageIndex = e.NewPageIndex;
        BindGridDraft();
    }
    protected void LinkEdit_Click(object sender, EventArgs e)
    {
        LinkButton LnkSeletedRow = sender as LinkButton;
        GridViewRow row = LnkSeletedRow.NamingContainer as GridViewRow;

        Label LblServiceName = (Label)row.FindControl("LblServiceName");
        HiddenField Hid_Service_Type = (HiddenField)row.FindControl("Hid_Service_Type");
        HiddenField Hid_Dept_Name = (HiddenField)row.FindControl("Hid_Dept_Name");        

        int intServiceId = Convert.ToInt32(gvDraftService.DataKeys[row.RowIndex].Values["intServiceId"]);
        string strApplicationKey = Convert.ToString(gvDraftService.DataKeys[row.RowIndex].Values["str_ApplicationNo"]);
        string strProposalNo = Convert.ToString(gvDraftService.DataKeys[row.RowIndex].Values["strProposalId"]);
        string strGroupKey = Convert.ToString(gvDraftService.DataKeys[row.RowIndex].Values["vchTranscationNo"]);
        int intExternalType = Convert.ToInt32(gvDraftService.DataKeys[row.RowIndex].Values["intExternalType"]);
        string strUrl = Convert.ToString(gvDraftService.DataKeys[row.RowIndex].Values["Str_ExtrnalServiceUrl"]); 

        string strServiceName = LblServiceName.Text;       
        int intServiceType = Convert.ToInt32(Hid_Service_Type.Value);
        string strDeptName = Hid_Dept_Name.Value;
        decimal decAmount = 0;
        int intCompletedStatus = 0;

        /*-----------------------------------------------------------------------------------*/

        DataTable dt = new DataTable();
        dt.Columns.Add("intSlNo", typeof(int));
        dt.Columns.Add("intServiceId", typeof(string));       
        dt.Columns.Add("vchServiceName", typeof(string));
        dt.Columns.Add("intServiceType", typeof(string));
        dt.Columns.Add("intExternalType", typeof(string));
        dt.Columns.Add("vchProposalNo", typeof(string));
        dt.Columns.Add("decAmount", typeof(string));
        dt.Columns.Add("intCompletedStatus", typeof(string));
        dt.Columns.Add("vchApplicationKey", typeof(string));
        dt.Columns.Add("vchUrl", typeof(string));
        dt.Columns.Add("vchUpdateUrl", typeof(string));
        dt.Columns.Add("vchDeptName", typeof(string));
        dt.Columns.Add("intHoaAccount", typeof(string));
        dt.Columns.Add("vchTrackingId", typeof(string));

        if (strGroupKey != "")
        {
            ServiceBusinessLayer objService = new ServiceBusinessLayer();
            DataTable dtApp = objService.GetApplicationByTrackingId(strGroupKey);
            if (dtApp.Rows.Count > 0)
            {
                for (int i = 0; i < dtApp.Rows.Count; i++)
                {
                    strApplicationKey = Convert.ToString(dtApp.Rows[i]["VCH_APPLICATION_UNQ_KEY"]);
                    intServiceId = Convert.ToInt32(dtApp.Rows[i]["INT_SERVICEID"]);
                    strProposalNo = Convert.ToString(dtApp.Rows[i]["VCH_PROPOSALID"]);
                    decAmount = Convert.ToDecimal(dtApp.Rows[i]["NUM_PAYMENT_AMOUNT"]);
                    intExternalType = Convert.ToInt32(dtApp.Rows[i]["INT_EXTERNAL_TYPE"]);
                    strServiceName = Convert.ToString(dtApp.Rows[i]["VCH_SERVICENAME"]);
                    intServiceType = Convert.ToInt32(dtApp.Rows[i]["INT_SERVICE_TYPE"]);
                    strUrl = Convert.ToString(dtApp.Rows[i]["VCH_EXTERNAL_SERVICE_URL"]);
                    strDeptName = Convert.ToString(dtApp.Rows[i]["nvchLevelName"]);

                    //if (intServiceType == 0 && intExternalType == 0) ////If Internal service
                    //{
                    //    intCompletedStatus = 1;
                    //}

                    dt.Rows.Add(i + 1, intServiceId, strServiceName, intServiceType, intExternalType, strProposalNo, decAmount, intCompletedStatus, strApplicationKey, strUrl, "", strDeptName, 0, strGroupKey);
                }
            }
        }
        else
        {
            //if(intServiceType==0 && intExternalType==0)
            //{
            //    intCompletedStatus = 1;
            //}

            dt.Rows.Add(1, intServiceId, strServiceName, intServiceType, intExternalType, strProposalNo, decAmount, intCompletedStatus, strApplicationKey, strUrl, "", strDeptName, 0, strGroupKey);
        }

        Session["SvcMasterData"] = dt;
        Response.Redirect("ServiceProcess.aspx?FormId=" + intServiceId + "&AppKey=" + strApplicationKey + "&ProposalNo=" + strProposalNo + "&ReqMode=M" + "&GroupKey=" + strGroupKey);
    }
    private string GOIPAS(string strApplicationKey)
    {
        string EncryptValue = "";
        DataTable dt = new DataTable();
        try
        {
            SqlCommand cmd = new SqlCommand();
            if (conn.State == ConnectionState.Closed)
            {
                conn.Open();
            }
            try
            {
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_GOIPAS_SERVICE_DISPLAY";
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@INT_INVESTOR_ID", Convert.ToInt32(Session["InvestorId"].ToString()));
                cmd.Parameters.AddWithValue("@VCH_ACTION", "DRAFTSERVICEINFO");
                cmd.Parameters.AddWithValue("@VCH_APPLICATION_UNQ_KEY", strApplicationKey);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
            }
            catch (Exception ex)
            {
                Util.LogError(ex, "GOIPASSP");
            }
            finally
            {
                cmd = null;
                conn.Close();
            }
            if (dt.Rows.Count > 0)
            {
                EncryptDecryptQueryString obj = new EncryptDecryptQueryString();
                string Data = "" + dt.Rows[0]["VCH_PAN"].ToString() + "&" + dt.Rows[0]["VCH_EMAIL"].ToString() + "&" + dt.Rows[0]["VCH_UNIQUEID"].ToString() + "&" + dt.Rows[0]["INT_DISTRICT"].ToString() + "&" + dt.Rows[0]["VCH_APPLICATION_UNQ_KEY"].ToString() + "&" + ConfigurationManager.AppSettings["GOSWIFTDRAFTURL"].ToString() + "";
                EncryptValue = obj.Encrypt(Data, "m8s3e3k5");
            }
            else
            {
                EncryptValue = "";
            }
        }
        catch (Exception ex)
        {
            Util.LogError(ex, "GOIPASENC");
        }
        return EncryptValue;
    }
    private string BPAS(string strApplicationKey)
    {
        DataTable dt = new DataTable();
        string EncryptValue = "";
        try
        {
            SqlCommand cmd = new SqlCommand();
            if (conn.State == ConnectionState.Closed)
            {
                conn.Open();
            }
            try
            {
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_BPAS_SERVICE_DISPLAY";
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@INT_INVESTOR_ID", Convert.ToInt32(Session["InvestorId"].ToString()));
                cmd.Parameters.AddWithValue("@VCH_ACTION", "DRAFTSERVICEINFO");
                cmd.Parameters.AddWithValue("@VCH_APPLICATION_UNQ_KEY", strApplicationKey);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
            }
            catch (Exception ex)
            {
                Util.LogError(ex, "BPASSP");
            }
            finally
            {
                cmd = null;
                conn.Close();
            }

            if (dt.Rows.Count > 0)
            {
                string AppBmcUrl = ConfigurationManager.AppSettings["BPASCHECKSTATUSURL"].ToString();
                var client = new RestClient("" + AppBmcUrl + "");
                var request = new RestRequest(Method.POST);
                request.AddHeader("postman-token", "487391e8-90a4-0edf-d80a-85927ba52b8f");
                request.AddHeader("cache-control", "no-cache");
                request.AddHeader("authorization", "Basic YmJzcm9uZUAyMDE4OlZLY0VoNFduQk9SVXAyY21GUmQzWTBSell4UVcxV1I=");
                request.AddHeader("content-type", "application/json");
                request.AddParameter("application/json", "{\"action\":\"encrypt\",\"encString\":\"" + dt.Rows[0]["VCH_CONTACT_FIRSTNAME"].ToString() + "~::~" + dt.Rows[0]["VCH_CONTACT_MIDDLENAME"].ToString() + "~::~" + dt.Rows[0]["VCH_CONTACT_LASTNAME"].ToString() + "~::~" + dt.Rows[0]["VCH_OFF_MOBILE"].ToString() + "~::~" + dt.Rows[0]["VCH_EMAIL"].ToString() + "~::~" + dt.Rows[0]["VCH_INV_USERID"].ToString() + "~::~" + dt.Rows[0]["VCH_APPLICATION_UNQ_KEY"].ToString() + "~::~" + ConfigurationManager.AppSettings["GOSWIFTDRAFTURL"].ToString() + "~::~" + "2" + "\"}", ParameterType.RequestBody);
                IRestResponse response = client.Execute(request);
                string JSON = response.Content;
                var dict = new JavaScriptSerializer().Deserialize<Dictionary<string, object>>(JSON);
                EncryptValue = dict["result"].ToString();
            }
            else
            {
                string AppBmcUrl = ConfigurationManager.AppSettings["BPASCHECKSTATUSURL"].ToString();
                var client = new RestClient("" + AppBmcUrl + "");
                var request = new RestRequest(Method.POST);
                request.AddHeader("postman-token", "487391e8-90a4-0edf-d80a-85927ba52b8f");
                request.AddHeader("cache-control", "no-cache");
                request.AddHeader("authorization", "Basic YmJzcm9uZUAyMDE4OlZLY0VoNFduQk9SVXAyY21GUmQzWTBSell4UVcxV1I=");
                request.AddHeader("content-type", "application/json");
                request.AddParameter("application/json", "{\"action\":\"encrypt\",\"encString\":\"" + "NA" + "~::~" + "NA" + "~::~" + "NA" + "~::~" + "NA" + "~::~" + "NA" + "~::~" + "NA" + "~::~" + "NA" + "~::~" + ConfigurationManager.AppSettings["GOSWIFTDRAFTURL"].ToString() + "~::~" + "2" + "\"}", ParameterType.RequestBody);
                IRestResponse response = client.Execute(request);
                string JSON = response.Content;
                var dict = new JavaScriptSerializer().Deserialize<Dictionary<string, object>>(JSON);
                EncryptValue = dict["result"].ToString();
            }
        }
        catch (Exception ex)
        {
            Util.LogError(ex, "BPASENC");
        }
        return EncryptValue;
    }
    private string PAReSHRAM(string strApplicationKey)
    {
        string EncryptValue = "";
        DataTable dt = new DataTable();
        try
        {
            SqlCommand cmd = new SqlCommand();
            if (conn.State == ConnectionState.Closed)
            {
                conn.Open();
            }
            try
            {
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_PAReSHRAM_SERVICE_DISPLAY";
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@INT_INVESTOR_ID", Convert.ToInt32(Session["InvestorId"].ToString()));
                cmd.Parameters.AddWithValue("@VCH_ACTION", "DRAFTSERVICEINFO");
                cmd.Parameters.AddWithValue("@VCH_APPLICATION_UNQ_KEY", strApplicationKey);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
            }
            catch (Exception ex)
            {
                Util.LogError(ex, "PAReSHRAMSP");
            }
            finally
            {
                cmd = null;
                conn.Close();
            }
            if (dt.Rows.Count > 0)
            {
                string Industry_name = Uri.EscapeDataString(dt.Rows[0]["VCH_INV_NAME"].ToString());
                EncryptValue = "appln_id=" + dt.Rows[0]["VCH_APPLICATION_UNQ_KEY"].ToString() + "&service_code=" + dt.Rows[0]["INT_SERVICEID"].ToString() + "&pan=" + dt.Rows[0]["VCH_PAN"].ToString() + "&name=" + dt.Rows[0]["VCH_CONTACT_FIRSTNAME"].ToString() + "&mobile_number=" + dt.Rows[0]["VCH_OFF_MOBILE"].ToString() + "&email=" + dt.Rows[0]["VCH_EMAIL"].ToString() + "&est_name=" + Industry_name;
            }
            else
            {
                EncryptValue = "appln_id=" + "" + "&service_code=" + "" + "&pan=" + "" + "&name=" + "" + "&mobile_number=" + "" + "&email=" + "" + "&est_name=''";
            }
        }
        catch (Exception ex)
        {
            Util.LogError(ex, "PAReSHRAMENC");
        }
        return EncryptValue;
    }

    private string FOREST(string strApplicationKey)
    {
        string EncryptValue = "";
        DataTable dt = new DataTable();
        try
        {
            SqlCommand cmd = new SqlCommand();
            if (conn.State == ConnectionState.Closed)
            {
                conn.Open();
            }
            try
            {
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_FOREST_SERVICE_DISPLAY";
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@INT_INVESTOR_ID", Convert.ToInt32(Session["InvestorId"].ToString()));
                cmd.Parameters.AddWithValue("@VCH_ACTION", "DRAFTSERVICEINFO");
                cmd.Parameters.AddWithValue("@VCH_APPLICATION_UNQ_KEY", strApplicationKey);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
            }
            catch (Exception ex)
            {
                Util.LogError(ex, "FORESTSP");
            }
            finally
            {
                cmd = null;
                conn.Close();
            }
            if (dt.Rows.Count > 0)
            {
                string Industry_name = Uri.EscapeDataString(dt.Rows[0]["VCH_INV_NAME"].ToString());
                EncryptValue = "appln_id=" + dt.Rows[0]["VCH_APPLICATION_UNQ_KEY"].ToString() + "&service_code=" + dt.Rows[0]["INT_SERVICEID"].ToString() + "&pan=" + dt.Rows[0]["VCH_PAN"].ToString() + "&name=" + dt.Rows[0]["VCH_CONTACT_FIRSTNAME"].ToString() + "&mobile_number=" + dt.Rows[0]["VCH_OFF_MOBILE"].ToString() + "&email=" + dt.Rows[0]["VCH_EMAIL"].ToString() + "&est_name=" + Industry_name + "&UserId=" + Session["InvestorId"].ToString();
            }
            else
            {
                EncryptValue = "appln_id=" + "" + "&service_code=" + "" + "&pan=" + "" + "&name=" + "" + "&mobile_number=" + "" + "&email=" + "" + "&est_name=''" + "&UserId=''";
            }
        }
        catch (Exception ex)
        {
            Util.LogError(ex, "FORESTSP");
        }
        return EncryptValue;
    }
    private string FIRE(string strApplicationKey)
    {
        string EncryptValue = "";
        DataTable dt = new DataTable();
        try
        {
            SqlCommand cmd = new SqlCommand();
            if (conn.State == ConnectionState.Closed)
            {
                conn.Open();
            }
            try
            {
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_FIRE_SERVICE_DISPLAY";
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@INT_INVESTOR_ID", Convert.ToInt32(Session["InvestorId"].ToString()));
                cmd.Parameters.AddWithValue("@VCH_ACTION", "DRAFTSERVICEINFO");
                cmd.Parameters.AddWithValue("@VCH_APPLICATION_UNQ_KEY", strApplicationKey);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
            }
            catch (Exception ex)
            {
                Util.LogError(ex, "FIRESP");
            }
            finally
            {
                cmd = null;
                conn.Close();
            }
            if (dt.Rows.Count > 0)
            {
                var client = new RestClient("" + ConfigurationManager.AppSettings["FIRECHECKSTATUSURL"].ToString() + "?name='" + dt.Rows[0]["VCH_INV_NAME"].ToString() + "'&email='" + dt.Rows[0]["VCH_EMAIL"].ToString() + "'&mobile='" + dt.Rows[0]["VCH_OFF_MOBILE"].ToString() + "'&serviceId=" + dt.Rows[0]["INT_SERVICEID"].ToString() + "&applicationId='" + dt.Rows[0]["VCH_APPLICATION_UNQ_KEY"].ToString() + "'&mode=" + 2 + "&source='GOSWIFT'&returnUrl='" + ConfigurationManager.AppSettings["GOSWIFTDRAFTURL"].ToString() + "'");
                client.Timeout = -1;
                var request = new RestRequest(Method.GET);
                request.AlwaysMultipartFormData = true;
                IRestResponse response = client.Execute(request);
                Util.LogRequestResponse("FireService", "ResponsStatusCodeFromFireservice", response.StatusCode.ToString());
                string JSON = response.Content;
                dynamic data = JObject.Parse(JSON);

                //var dict = new JavaScriptSerializer().Deserialize<Dictionary<string, object>>(JSON);

                Util.LogRequestResponse("FireService", "ResponsFromFireservice", JSON);
                EncryptValue = data["result"].ToString();
            }
            else
            {
                var client = new RestClient("" + ConfigurationManager.AppSettings["FIRECHECKSTATUSURL"].ToString() + "?name=''&email=''&mobile=''&serviceId=" + 0 + "&applicationId=''&mode=" + 2 + "&source='GOSWIFT'&returnUrl='" + ConfigurationManager.AppSettings["GOSWIFTDRAFTURL"].ToString() + "'");
                client.Timeout = -1;
                var request = new RestRequest(Method.GET);
                request.AlwaysMultipartFormData = true;
                IRestResponse response = client.Execute(request);
                Util.LogRequestResponse("FireService", "ResponsStatusCodeFromFireservice", response.StatusCode.ToString());
                string JSON = response.Content;
                dynamic data = JObject.Parse(JSON);
                //var dict = new JavaScriptSerializer().Deserialize<Dictionary<string, object>>(JSON);

                EncryptValue = data["result"].ToString();
                Util.LogRequestResponse("FireService", "EncriptedResponcData", "EncriptedResponcData :-" + data["result"].ToString());
            }
        }
        catch (Exception ex)
        {
            Util.LogError(ex, "FIREENC");
        }
        return EncryptValue;
    }
    private string EXCISE(string strApplicationKey)
    {
        string strplaintext = "";
        string EncryptValue = "";
        string strSuppliedKey = "?åLˆ'KX¾p ;™¶%M8º}ÌqE-ƒU§©	;±½";
        byte[] key = { };
        key = Encoding.ASCII.GetBytes(strSuppliedKey);
        DataTable dt = new DataTable();
        try
        {
            SqlCommand cmd = new SqlCommand();
            if (conn.State == ConnectionState.Closed)
            {
                conn.Open();
            }
            try
            {
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_EXCISE_SERVICE_DISPLAY";
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@INT_INVESTOR_ID", Convert.ToInt32(Session["InvestorId"].ToString()));
                cmd.Parameters.AddWithValue("@VCH_ACTION", "DRAFTSERVICEINFO");
                cmd.Parameters.AddWithValue("@VCH_APPLICATION_UNQ_KEY", strApplicationKey);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
            }
            catch (Exception ex)
            {
                Util.LogError(ex, "EXCISSP");
            }
            finally
            {
                cmd = null;
                conn.Close();
            }
            if (dt.Rows.Count > 0)
            {
                strplaintext = "" + dt.Rows[0]["VCH_INV_NAME"].ToString() + "|" + dt.Rows[0]["VCH_OFF_MOBILE"].ToString() + "|" + dt.Rows[0]["INT_SERVICEID"].ToString() + "|" + dt.Rows[0]["VCH_APPLICATION_UNQ_KEY"].ToString() + "|2";
                EncryptValue = Exciseencryptalgorthim(strplaintext, key);
            }
            else
            {
                strplaintext = "NA|NA|NA|NA|2";
                EncryptValue = Exciseencryptalgorthim(strplaintext, key);
            }
        }
        catch (Exception ex)
        {
            Util.LogError(ex, "EXCISEENC");
        }
        return EncryptValue;
    }
    public static string Exciseencryptalgorthim(string plainText, byte[] Key)
    {
        if (plainText == null || plainText.Length <= 0)
            throw new ArgumentNullException("plainText");
        if (Key == null || Key.Length <= 0)
            throw new ArgumentNullException("Key");
        byte[] encrypted;
        string base64encrypted;
        using (AesManaged aesAlg = new AesManaged())
        {
            aesAlg.Key = Key;
            aesAlg.Mode = CipherMode.ECB;
            ICryptoTransform encryptor = aesAlg.CreateEncryptor(aesAlg.Key, aesAlg.IV);
            using (MemoryStream msEncrypt = new MemoryStream())
            {
                using (CryptoStream csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                {
                    using (StreamWriter swEncrypt = new StreamWriter(csEncrypt))
                    {
                        swEncrypt.Write(plainText);
                    }
                    encrypted = msEncrypt.ToArray();
                }
            }
        }
        base64encrypted = Convert.ToBase64String(encrypted, 0, encrypted.Length);
        return base64encrypted.Replace("/", "-");
    }
    public string EIT(string strApplicationKey)
    {
        string EncryptValue = "";
        DataTable dt = new DataTable();
        try
        {
            SqlCommand cmd = new SqlCommand();
            if (conn.State == ConnectionState.Closed)
            {
                conn.Open();
            }
            
            cmd.Connection = conn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "USP_EIT_SERVICE_DISPLAY";
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@INT_INVESTOR_ID", Convert.ToInt32(Session["InvestorId"].ToString()));
            cmd.Parameters.AddWithValue("@VCH_ACTION", "DRAFTSERVICEINFO");
            cmd.Parameters.AddWithValue("@VCH_APPLICATION_UNQ_KEY", strApplicationKey);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            
            if (dt.Rows.Count > 0)
            {
                // EncryptValue = "authorised_person=" + dt.Rows[0]["VCH_CONTACT_FIRSTNAME"].ToString() + "&phone_number=" + dt.Rows[0]["VCH_OFF_MOBILE"].ToString() + "&email=" + dt.Rows[0]["VCH_EMAIL"].ToString() + "&district=" + dt.Rows[0]["vchDistrictName"].ToString() + "&uniqid=" + dt.Rows[0]["VCH_APPLICATION_UNQ_KEY"].ToString() + "&ServiceId=" + dt.Rows[0]["INT_SERVICEID"].ToString() + "";

                EncryptValue = "AppNo=" + strApplicationKey.ToString() + "&ServiceId=" + dt.Rows[0]["INT_SERVICEID"].ToString() + "&MobileNo=" + dt.Rows[0]["VCH_OFF_MOBILE"].ToString() + "&EmailId=" + dt.Rows[0]["VCH_EMAIL"].ToString() + "&CompanyName=" + dt.Rows[0]["VCH_INV_NAME"].ToString() + "";

            }
            else
            {
                EncryptValue = "authorised_person=" + "" + "&phone_number=" + "" + "&email=" + "" + "&district=" + "" + "&uniqid=" + "" + "&ServiceId=" + "" + "";
            }
        }
        catch (Exception ex)
        {
            Util.LogError(ex, "MobileTower");
        }
        return EncryptValue;
    }
    private string OSBC(string strApplicationKey)
    {
        string EncryptValue = "";
        DataTable dt = new DataTable();
        ExciseOSBCServiceReference.OSBCSoftSoapClient objEx = new ExciseOSBCServiceReference.OSBCSoftSoapClient();
        ExciseOSBCServiceReference.SupDetails objEntity = new ExciseOSBCServiceReference.SupDetails();
        try
        {
            SqlCommand cmd = new SqlCommand();
            if (conn.State == ConnectionState.Closed)
            {
                conn.Open();
            }
            try
            {
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_OSBC_SERVICE_DISPLAY";
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@INT_INVESTOR_ID", Convert.ToInt32(Session["InvestorId"].ToString()));
                cmd.Parameters.AddWithValue("@VCH_ACTION", "DRAFTSERVICEINFO");
                cmd.Parameters.AddWithValue("@VCH_APPLICATION_UNQ_KEY", strApplicationKey);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
            }
            catch (Exception ex)
            {
                Util.LogError(ex, "OSBCSP");
            }
            finally
            {
                cmd = null;
                conn.Close();
            }
            if (dt.Rows.Count > 0)
            {
                objEntity.Application_No = dt.Rows[0]["VCH_APPLICATION_UNQ_KEY"].ToString();
                objEntity.GoSwiftUserID = dt.Rows[0]["VCH_INV_USERID"].ToString();
                objEntity.MobileNo = dt.Rows[0]["VCH_OFF_MOBILE"].ToString();
                objEntity.Name = dt.Rows[0]["VCH_CONTACT_FIRSTNAME"].ToString();
                objEntity.Email = dt.Rows[0]["VCH_EMAIL"].ToString();
                objEntity.Sector_Type = dt.Rows[0]["VCH_SECTOR"].ToString();
                objEntity.Sector_Subtype = dt.Rows[0]["vchSubSectorName"].ToString();
                objEntity.ServiceID = dt.Rows[0]["INT_SERVICEID"].ToString();
                objEntity.Source = "GOSWIFT";
                objEntity.Active_Status = "Yes";
                EncryptValue = objEx.AESEncryptForSignUP(objEntity);
            }
            else
            {
                objEntity.Application_No = "";
                objEntity.GoSwiftUserID = "";
                objEntity.MobileNo = "";
                objEntity.Name = "";
                objEntity.Email = "";
                objEntity.Sector_Type = "";
                objEntity.Sector_Subtype = "";
                objEntity.ServiceID = "";
                objEntity.Source = "GOSWIFT";
                objEntity.Active_Status = "Yes";
                EncryptValue = objEx.AESEncryptForSignUP(objEntity);
            }
        }
        catch (Exception ex)
        {
            Util.LogError(ex, "OSBCENC");
        }
        return EncryptValue;
    }

    /// <summary>
    /// this method used create JSON data for draft application of new power connection by Mo-Biduyt api
    /// </summary>
    private string ENERGY(string strApplicationKey)
    {
        string EncryptValue = "";
        DataTable dt = new DataTable();
        try
        {
            SqlCommand cmd = new SqlCommand();
            if (conn.State == ConnectionState.Closed)
            {
                conn.Open();
            }

            cmd.Connection = conn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "USP_Energy_SERVICE_DISPLAY";
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@INT_INVESTOR_ID", Convert.ToInt32(Session["InvestorId"].ToString()));
            cmd.Parameters.AddWithValue("@VCH_ACTION", "DRAFTSERVICEINFO");
            cmd.Parameters.AddWithValue("@VCH_APPLICATION_UNQ_KEY", strApplicationKey);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);

            if (dt.Rows.Count > 0)
            {

                EncryptValue = "{\"serviceId\":\"" + dt.Rows[0]["INT_SERVICEID"].ToString() + "\",\"name\":\"" + dt.Rows[0]["VCH_CONTACT_FIRSTNAME"].ToString() + "\",\"pan\":\"" + dt.Rows[0]["VCH_PAN"].ToString() + "\",\"email\":\"" + dt.Rows[0]["VCH_EMAIL"].ToString() + "\",\"mobile\":\"" + dt.Rows[0]["VCH_OFF_MOBILE"].ToString() + "\",\"goSwiftApplicationId\":\"" + strApplicationKey + "\"}";

            }
            else
            {
                EncryptValue = "{\"serviceid\":\"\",\"goSwiftApplicationId\":\"\",\"name\":\"\",\"pan\":\"\",\"email\":\"\",\"mobile\":\"\"}";

            }

        }
        catch (Exception ex)
        {
            Util.LogError(ex, "Energy");
        }
        return EncryptValue;
    }

    private string DRUG(string strApplicationKey)
    {
        string strEncryptValue = "";
        DataTable dt = new DataTable();
        try
        {
            SqlCommand cmd = new SqlCommand();
            if (conn.State == ConnectionState.Closed)
            {
                conn.Open();
            }
            cmd.Connection = conn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "USP_DRUG_SERVICE_DISPLAY";
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@INT_INVESTOR_ID", Convert.ToInt32(Session["InvestorId"].ToString()));
            cmd.Parameters.AddWithValue("@VCH_ACTION", "DRAFTSERVICEINFO");
            cmd.Parameters.AddWithValue("@VCH_APPLICATION_UNQ_KEY", strApplicationKey);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            //string output = objSvc.ExternalServiceData("GA", Convert.ToInt32(str_FormId), str_ProposalNo, Convert.ToInt32(Session["InvestorId"]), Session["PAN"].ToString());
            

            if (dt.Rows.Count > 0)
            {
                strEncryptValue = "{\"pan_no\":\"" + dt.Rows[0]["VCH_PAN"].ToString() + "\",\"mobile_no\":\"" + dt.Rows[0]["VCH_OFF_MOBILE"].ToString() + "\",\"email\":\"" + dt.Rows[0]["VCH_EMAIL"].ToString() + "\",\"organization_name\":\"" + dt.Rows[0]["VCH_INV_NAME"].ToString() + "\",\"referene_id\":\"" + strApplicationKey + "\",\"dept_id\":\"" + dt.Rows[0]["INT_SERVICEID"].ToString() + "\"}";
            }
            else
            {
                strEncryptValue = "{\"pan_no\":\"\",\"mobile_no\":\"\",\"email\":\"\",\"organization_name\":\"\",\"referene_id\":\"\",\"dept_id\":\"\"}";
            }
        }
        catch (Exception ex)
        {
            Util.LogError(ex, "Drugs");
        }
        return strEncryptValue;
    }


    private string TRADELICENSE(string strApplicationKey)
    {
        string strEncryptValue = "";
        DataTable dt = new DataTable();
        try
        {
            SqlCommand cmd = new SqlCommand();
            if (conn.State == ConnectionState.Closed)
            {
                conn.Open();
            }
            cmd.Connection = conn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "USP_TRADE_LICENSE_SERVICE_DISPLAY";
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@INT_INVESTOR_ID", Convert.ToInt32(Session["InvestorId"].ToString()));
            cmd.Parameters.AddWithValue("@VCH_ACTION", "DRAFTSERVICEINFO");
            cmd.Parameters.AddWithValue("@VCH_APPLICATION_UNQ_KEY", strApplicationKey);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            string strTradeLicenseSecurityKey = ConfigurationManager.AppSettings["TradeLicenseSecurityKey"].ToString();
         
           
                if (dt.Rows.Count > 0)
                {
                    strEncryptValue = "{\"RequestInfo\": {\"apiId\": \"Rainmaker\",\"ver\": \".01\",\"action\": \"\",\"did\": \"1\",\"key\": \"\",\"msgId\": \"20170310130900|en_IN\",\"requesterId\": \"\"},\r\n\"GoSwiftInput\": {\"tenantId\": \"od\",\"applicationNo\": \"" + strApplicationKey.ToString() + "\",\"serviceId\": \"" + dt.Rows[0]["INT_SERVICEID"].ToString() + "\",\"mobileNo\": \"" + dt.Rows[0]["VCH_OFF_MOBILE"].ToString() + "\",\"emailId\":\"" + dt.Rows[0]["VCH_EMAIL"].ToString() + "\",\r\n\"companyName\": \"" + dt.Rows[0]["VCH_INV_NAME"].ToString() + "\",\"name\":\"" + dt.Rows[0]["VCH_CONTACT_FIRSTNAME"].ToString() + "\",\"securityToken\":\"" + strTradeLicenseSecurityKey.ToString() + "\"}}";
                }
                else
                {
                    strEncryptValue = "{\"pan_no\":\"\",\"mobile_no\":\"\",\"email\":\"\",\"organization_name\":\"\",\"referene_id\":\"\",\"dept_id\":\"\"}";
                }
          
        }
        catch (Exception ex)
        {
            Util.LogError(ex, "Drugs");
        }
        return strEncryptValue;
    }


    protected void BtnApplyMultipe_Click(object sender, EventArgs e)
    {
        try
        {
            int intCheckStatus = 0;
            int intFormCount = 0;

            /*------------------------------------------------------------------------------------*/
            ///// The Description for below DataTable provided in "DepartmentClearance.aspx" Page.
            /*------------------------------------------------------------------------------------*/
            DataTable dt = new DataTable();

            dt.Columns.Add("intSlNo", typeof(int));
            dt.Columns.Add("intServiceId", typeof(string));
            dt.Columns.Add("vchFormName", typeof(string));
            dt.Columns.Add("vchServiceName", typeof(string));
            dt.Columns.Add("intServiceType", typeof(string));
            dt.Columns.Add("intExternalType", typeof(string));//changed by sourav on dated 10-03-2021
            dt.Columns.Add("vchProposalNo", typeof(string));
            dt.Columns.Add("decAmount", typeof(string));
            dt.Columns.Add("intCompletedStatus", typeof(string));
            dt.Columns.Add("vchApplicationKey", typeof(string));
            dt.Columns.Add("vchUrl", typeof(string));
            dt.Columns.Add("vchUpdateUrl", typeof(string));
            dt.Columns.Add("vchDeptName", typeof(string));
            dt.Columns.Add("intHoaAccount", typeof(string));

            for (int i = 0; i < gvDraftService.Rows.Count; i++)
            {
                int intServiceId = Convert.ToInt32(gvDraftService.DataKeys[i].Values["intServiceId"]);
                decimal decAmount = Convert.ToInt32(gvDraftService.DataKeys[i].Values["Dec_Amount"]);//changed by sourav on dated 10-03-2021
                int intServiceType = Convert.ToInt32(gvDraftService.DataKeys[i].Values["str_checkStatus"]);
                string strProposalNo = gvDraftService.DataKeys[i].Values["strProposalId"].ToString();
                string strApplicationKey = gvDraftService.DataKeys[i].Values["str_ApplicationNo"].ToString();
                int intExternalType = Convert.ToInt32(gvDraftService.DataKeys[i].Values["intExternalType"]);//changed by sourav on dated 10-03-2021
                string vchUrl = gvDraftService.DataKeys[i].Values["Str_ExtrnalServiceUrl"].ToString();
                CheckBox ChkBxSelect = (CheckBox)gvDraftService.Rows[i].FindControl("ChkBxSelect");
                Label LblServiceName = (Label)gvDraftService.Rows[i].FindControl("LblServiceName");

                if (ChkBxSelect.Checked)
                {
                    intCheckStatus = 1;
                    intFormCount = intFormCount + 1;

                    string strFormName = LblServiceName.Text.Length > 20 ? LblServiceName.Text.Substring(0, 20) + "..." : LblServiceName.Text;
                    int intcompletedstatus = 0;
                    string strRes = "SELECT ApplicationNo from T_CMN_FIN_DETAILS_LOG WHERE  ApplicationNo in('" + strApplicationKey + "')";

                    SqlCommand cmd = new SqlCommand(strRes, conn);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);

                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        for (int i1 = 0; i1 < ds.Tables[0].Rows.Count; i1++)
                        {
                            intcompletedstatus = 1;
                        }
                    }
                    if (dt.Rows.Count > 0)
                    {
                        if (vchUrl != "")
                        {
                            dt.Rows.Add(intFormCount, intServiceId, strFormName, LblServiceName.Text, intServiceType, intExternalType, strProposalNo, decAmount, intcompletedstatus, strApplicationKey, vchUrl + "&ReqMode=M");
                        }
                        else
                        {
                            dt.Rows.Add(intFormCount, intServiceId, strFormName, LblServiceName.Text, intServiceType, intExternalType, strProposalNo, decAmount, 1, strApplicationKey, "FormEditView1.aspx?FormId=" + intServiceId + "&AppKey=" + strApplicationKey + "&ProposalNo=" + strProposalNo);
                        }
                    }
                    else
                    {
                        if (vchUrl != "")
                        {
                            dt.Rows.Add(intFormCount, intServiceId, strFormName, LblServiceName.Text, intServiceType, intExternalType, strProposalNo, decAmount, intcompletedstatus, strApplicationKey, vchUrl + "&ReqMode=M");
                        }
                        else
                        {
                            dt.Rows.Add(intFormCount, intServiceId, strFormName, LblServiceName.Text, intServiceType, intExternalType, strProposalNo, decAmount, 1, strApplicationKey, "FormEditView1.aspx?FormId=" + intServiceId + "&AppKey=" + strApplicationKey + "&ProposalNo=" + strProposalNo);
                        }
                    }
                }
            }

            if (intCheckStatus == 0)
            {
                ScriptManager.RegisterStartupScript(this, typeof(Page), "Click", "jAlert('<strong>Please select at least one check box to proceed !</strong>');", true);
                return;
            }

            Session["SvcMasterData"] = dt;
            Response.Redirect("ServiceProcess.aspx?ReqMode=M", false); ////M-Multiple Apply, S-Single Apply
        }
        catch (Exception ex)
        {
            Util.LogError(ex, "DraftService");
        }
    }
    protected void lbtnAll_Click(object sender, EventArgs e)
    {
        try
        {
            if (lbtnAll.Text == "All")
            {
                lbtnAll.Text = "Paging";
                this.gvDraftService.PageIndex = 0;
                this.gvDraftService.AllowPaging = false;
            }
            else
            {
                lbtnAll.Text = "All";
                this.gvDraftService.AllowPaging = true;
            }

            BindGridDraft();
        }
        catch (Exception ex)
        {
            Util.LogError(ex, "DraftService");
        }
    }
    protected void DisplayPaging()
    {
        try
        {
            if (gvDraftService.Rows.Count > 0)
            {
                lblPaging.Visible = true;
                lbtnAll.Visible = true;
                if (gvDraftService.PageIndex + 1 == gvDraftService.PageCount)
                {
                    lblPaging.Text = "Results <b>" + ((Label)gvDraftService.Rows[0].FindControl("lblsl")).Text + "</b> - <b>" + dtval + "</b> of <b>" + dtval + "</b>";
                }
                else
                {
                    this.lblPaging.Text = "Results <b>" + ((Label)gvDraftService.Rows[0].FindControl("lblsl")).Text + "</b> - <b>" + Convert.ToString(Convert.ToInt32(((Label)gvDraftService.Rows[0].FindControl("lblsl")).Text) + gvDraftService.PageSize - 1) + "</b> of <b>" + dtval + "</b>";
                }
            }
            else
            {
                lblPaging.Visible = false;
                lbtnAll.Visible = false;
            }
        }
        catch (Exception ex)
        {
            Util.LogError(ex, "DraftService");
        }
    }


    protected void ExDisplayPaging()
    {
        try
        {
            if (gvExDraftService.Rows.Count > 0)
            {
                ExlblPaging.Visible = true;
                ExlbtnAll.Visible = true;
                if (gvExDraftService.PageIndex + 1 == gvExDraftService.PageCount)
                {
                    ExlblPaging.Text = "Results <b>" + ((Label)gvExDraftService.Rows[0].FindControl("lblsl")).Text + "</b> - <b>" + Exdtval + "</b> of <b>" + Exdtval + "</b>";
                }
                else
                {
                    this.ExlblPaging.Text = "Results <b>" + ((Label)gvExDraftService.Rows[0].FindControl("lblsl")).Text + "</b> - <b>" + Convert.ToString(Convert.ToInt32(((Label)gvExDraftService.Rows[0].FindControl("lblsl")).Text) + gvExDraftService.PageSize - 1) + "</b> of <b>" + Exdtval + "</b>";
                }
            }
            else
            {
                ExlblPaging.Visible = false;
                ExlbtnAll.Visible = false;
            }
        }
        catch (Exception ex)
        {
            Util.LogError(ex, "DraftService");
        }
    }


    protected void gvExDraftService_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvExDraftService.PageIndex = e.NewPageIndex;
        BindGridDraft();
    }
    protected void ExLinkEdit_Click(object sender, EventArgs e)
    {
      try
      {

        
        LinkButton LnkSeletedRow = sender as LinkButton;
        GridViewRow row = LnkSeletedRow.NamingContainer as GridViewRow;
        string svcid = gvExDraftService.DataKeys[row.RowIndex].Values[1].ToString();
        string strApplicationKey = gvExDraftService.DataKeys[row.RowIndex].Values[8].ToString();
        string strProposalNo = gvExDraftService.DataKeys[row.RowIndex].Values[0].ToString();
        string strEncryptValue = "";
        string strResult = "";

        if (Convert.ToInt32(svcid) == 20)
        {
            strEncryptValue = BPAS(strApplicationKey);
            Response.Redirect(ConfigurationManager.AppSettings["BPASRedirectionURL"].ToString() + strEncryptValue);
        }
        else if (Convert.ToInt32(svcid) == 29)
        {
            strEncryptValue = GOIPAS(strApplicationKey);
            Response.Redirect(ConfigurationManager.AppSettings["GOIPASRedirectionURL"].ToString() + "?Query=" + strEncryptValue + "");
        }
        else if (Convert.ToInt32(svcid) == 62 || Convert.ToInt32(svcid) == 63)
        {
            strEncryptValue = FIRE(strApplicationKey);
            System.Threading.Thread.Sleep(10000);
            Response.Redirect(ConfigurationManager.AppSettings["FIREREDIRECTIONURL"].ToString() + "?Query=" + strEncryptValue + "");
            System.Threading.Thread.Sleep(10000);
        }
        else if (Convert.ToInt32(svcid) == 67 || Convert.ToInt32(svcid) == 68)
        {
            strEncryptValue = EXCISE(strApplicationKey);
            if (Convert.ToInt32(svcid) == 67)
            {
                var client = new RestClient(ConfigurationManager.AppSettings["EXCISESRREDIRECTIONURL"].ToString());
                client.FollowRedirects = false;
                Util.LogRequestResponse("EabakaryService", "Url :-", "Url :-" + ConfigurationManager.AppSettings["EXCISESRREDIRECTIONURL"].ToString());
                client.Timeout = -1;

                var request = new RestRequest(Method.POST);
                request.AddHeader("Content-Type", "application/json");
                request.AddParameter("application/json", "{\r\n    \"EncryptedString\":\"" + strEncryptValue + "\"\r\n}", ParameterType.RequestBody);
                IRestResponse response = client.Execute(request);
                strResult = response.StatusCode.ToString();
                if (response.StatusCode == HttpStatusCode.MovedPermanently)
                {
                    string strResponseLocationurl = (string)response.Headers
                                       .Where(x => x.Name == "Location")
                                       .Select(x => x.Value)
                                       .FirstOrDefault();
                    Util.LogRequestResponse("EabakaryService", "RedirectionUrl", strResponseLocationurl);
                    Response.Redirect(strResponseLocationurl);

                }
                else
                {
                    Util.LogRequestResponse("EabakaryService", "StatusCode", strResult.ToString());
                    Response.Redirect("DraftedServices.aspx");
                }
            }
            else
            {
                var client = new RestClient(ConfigurationManager.AppSettings["EXCISEGNSREDIRECTIONURL"].ToString());
                client.FollowRedirects = false;
                Util.LogRequestResponse("EabakaryService", "Url :-", "Url :-" + ConfigurationManager.AppSettings["EXCISESRREDIRECTIONURL"].ToString());
                client.Timeout = -1;
                var request = new RestRequest(Method.POST);
                request.AddHeader("Content-Type", "application/json");
                request.AddParameter("application/json", "{\r\n    \"EncryptedString\":\"" + strEncryptValue + "\"\r\n}", ParameterType.RequestBody);
                IRestResponse response = client.Execute(request);
                strResult = response.StatusCode.ToString();
                if (response.StatusCode == HttpStatusCode.MovedPermanently)
                {
                    string strResponseLocationurl = (string)response.Headers
                                       .Where(x => x.Name == "Location")
                                       .Select(x => x.Value)
                                       .FirstOrDefault();
                    Util.LogRequestResponse("EabakaryService", "RedirectionUrl", strResponseLocationurl);
                    Response.Redirect(strResponseLocationurl);

                }
                else
                {
                    Util.LogRequestResponse("EabakaryService", "StatusCode", strResult.ToString());
                    Response.Redirect("DraftedServices.aspx");
                }

            }
        }
        else if (Convert.ToInt32(svcid) == 69)
        {
            strEncryptValue = OSBC(strApplicationKey);
            Response.Redirect(ConfigurationManager.AppSettings["OSBCREDIRECTIONURL"].ToString() + "?encData=" + strEncryptValue + "");
        }
        else if (Convert.ToInt32(svcid) == 5 || Convert.ToInt32(svcid) == 6 || Convert.ToInt32(svcid) == 7 || Convert.ToInt32(svcid) == 34 || Convert.ToInt32(svcid) == 35 || Convert.ToInt32(svcid) == 36 || Convert.ToInt32(svcid) == 39 || Convert.ToInt32(svcid) == 40 || Convert.ToInt32(svcid) == 70 || Convert.ToInt32(svcid) == 71 || Convert.ToInt32(svcid) == 72 || Convert.ToInt32(svcid) == 37) // add by anil service 37 
        {
            strEncryptValue = PAReSHRAM(strApplicationKey);
            Response.Redirect(ConfigurationManager.AppSettings["PARESHRAMREDIRECTIONURL"].ToString() + "?" + strEncryptValue + "");
        }
        else if (Convert.ToInt32(svcid) == 73) // Mobile Tower service
        {
                strEncryptValue = EIT(strApplicationKey);
                //Response.Redirect(ConfigurationManager.AppSettings["MobileTowerRedirectionUrl"].ToString() + "?" + strEncryptValue + "");

                Util.LogRequestResponse("MobileTower", "Encriptiondata", strEncryptValue);



                #region For allow https from http url this below part need to add

                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12 | SecurityProtocolType.Ssl3;
                ServicePointManager.SecurityProtocol = (SecurityProtocolType)768 | (SecurityProtocolType)3072;

                #endregion
               



                Util.LogRequestResponse("MobileTower", "EITEncriptonUrl", ConfigurationManager.AppSettings["EitEncryptionUrl"].ToString());
                var options = new RestClient(ConfigurationManager.AppSettings["EitEncryptionUrl"].ToString())
                {
                    Timeout = -1
                };
                var client = new RestClient(options.BaseUrl);
                var request = new RestRequest("?" + strEncryptValue + "", Method.GET);
                IRestResponse response = client.Execute(request);



                Util.LogRequestResponse("MobileTower", "StatusCode", response.StatusCode.ToString());
                Util.LogRequestResponse("MobileTower", "ResponseContent", response.Content.ToString());


                if (response.StatusCode == HttpStatusCode.OK)
                {
                    string JSON = response.Content;
                    dynamic data = JObject.Parse(JSON);
                    Util.LogRequestResponse("FireService", "ResponsFromFireservice", JSON);
                    // var dict = new JavaScriptSerializer().Deserialize<Dictionary<string, object>>(JSON);

                    Boolean status = Convert.ToBoolean(data["success"]);
                    if (status)
                    {
                        string strEncryptData = Convert.ToString(data["encryptData"]);
                        string RedirectionUrl = ConfigurationManager.AppSettings["EitRedirectionUrl"].ToString() + strEncryptData.ToString();
                        Util.LogRequestResponse("MobileTower", "RedirectUrl", RedirectionUrl);
                        Response.Redirect(RedirectionUrl, true);

                    }


                }


        }
        else if (svcid == "25" || svcid == "26") // Tree Transit Service
        {
            
            strEncryptValue = FOREST(strApplicationKey);
            Response.Redirect(ConfigurationManager.AppSettings["TreeTransit"].ToString() + "?" + strEncryptValue + "");
        }
        else if (svcid == "16") // Energy department Continu from draft stage for new power connection service
        {

            strEncryptValue = ENERGY(strApplicationKey);

            Util.LogRequestResponse("EnergyService", "Encriptiondata", strEncryptValue);
            #region For allow https from http url this below part need to add

            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12 | SecurityProtocolType.Ssl3;
            ServicePointManager.SecurityProtocol = (SecurityProtocolType)768 | (SecurityProtocolType)3072;

            #endregion

            string TokenURL = ConfigurationManager.AppSettings["MoBiduytTokenGenerationUrl"].ToString();
            Util.LogRequestResponse("EnergyService", "TokenURL", TokenURL);
            var Client = new RestClient(TokenURL);
            Client.Timeout = -1;
            var Request = new RestRequest(Method.POST);
            Request.AddHeader("Content-Type", "application/json");
            Request.AddHeader("Authorization", "Basic R29Td2lmdC01Mzc0ODI5NDU0NzozMzYyNzc4OTI4");
            Request.AddHeader("Cookie", "ASP.NET_SessionId=rq2ca2ux1rsp3e1vjyphow3x");

            Request.AddParameter("application/json", strEncryptValue, ParameterType.RequestBody);
            IRestResponse EncriptionResponse = Client.Execute(Request);

            Util.LogRequestResponse("EnergyService", "TokenStatusCode", EncriptionResponse.StatusCode.ToString());
            if (EncriptionResponse.StatusCode == HttpStatusCode.OK)
            {
                var strResponseContent = EncriptionResponse.Content.ToString();
                Util.LogRequestResponse("EnergyService", "Token", strResponseContent);
                if (strResponseContent != "")
                {
                    ///Get the access token value.
                    string statusEncriptedDescription = JsonConvert.DeserializeObject<Dictionary<string, object>>(EncriptionResponse.Content)["statusDescription"].ToString();

                    Util.LogRequestResponse("EnergyService", "TokenDeserializeData", statusEncriptedDescription);
                    string RedirectionUrl = ConfigurationManager.AppSettings["MoBiduytRedirectionUrl"].ToString() + statusEncriptedDescription;
                    Util.LogRequestResponse("EnergyService", "RedirectUrl", RedirectionUrl);
                    Response.Redirect(RedirectionUrl);

                }
            }


        }
        else if (svcid == "30" || svcid == "31" || svcid == "32")
        {
                strEncryptValue = DRUG(strApplicationKey);
                Util.LogRequestResponse("DrugService", "Encriptiondata", strEncryptValue);
                #region For allow https from http url this below part need to add

                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12 | SecurityProtocolType.Ssl3;
                ServicePointManager.SecurityProtocol = (SecurityProtocolType)768 | (SecurityProtocolType)3072;

                #endregion
                string strDRUGURL = ConfigurationManager.AppSettings["DrugsLicenseUrl"].ToString();
                Util.LogRequestResponse("DrugService", "DrugsURL", strDRUGURL);
                var Client = new RestClient(strDRUGURL);
                Client.Timeout = -1;
                var Request = new RestRequest(Method.POST);

                Request.AddHeader("Content-Type", "application/json");
                Request.AddParameter("application/json", strEncryptValue, ParameterType.RequestBody);
                IRestResponse dataResponse = Client.Execute(Request);
                Util.LogRequestResponse("DrugService", "StatusCode", dataResponse.StatusCode.ToString());
                Util.LogRequestResponse("DrugService", "ResponseContent", dataResponse.Content.ToString());
                if (dataResponse.StatusCode == HttpStatusCode.OK)
                {
                    string JSON = dataResponse.Content;
                    dynamic data = JObject.Parse(JSON);//success
                    Util.LogRequestResponse("DrugService", "ApiSuccess", data["success"].ToString());

                    if (Convert.ToBoolean(data["success"]))
                    {
                        string strRedirectionUrl = Convert.ToString(data["redirect_url"]);
                        Util.LogRequestResponse("DrugService", "RedirectionUrl", strRedirectionUrl);
                        Response.Redirect(strRedirectionUrl);
                    }
                    else
                    {
                        Util.LogRequestResponse("DrugService", "FailureResponseContent", dataResponse.Content.ToString());
                    }
                }
        }
        else if(svcid == "52") //Trade Licenece Service
            {
                strEncryptValue = TRADELICENSE(strApplicationKey);
                Util.LogRequestResponse("TradeLicenece", "Encriptiondata", strEncryptValue);
                #region For allow https from http url this below part need to add

                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12 | SecurityProtocolType.Ssl3;
                ServicePointManager.SecurityProtocol = (SecurityProtocolType)768 | (SecurityProtocolType)3072;

                #endregion

                string strTradeLicenseEncryptUrl = ConfigurationManager.AppSettings["TradeLicenseEncryptUrl"].ToString();
                Util.LogRequestResponse("TradeLicenece", "TradeLicenseEncryptUrl", strTradeLicenseEncryptUrl);
                var Client = new RestClient(strTradeLicenseEncryptUrl);
                Client.Timeout = -1;
                var Request = new RestRequest(Method.POST);
                Request.AddHeader("Content-Type", "application/json");
                Request.AddParameter("application/json", strEncryptValue, ParameterType.RequestBody);
                IRestResponse dataResponse = Client.Execute(Request);
                Util.LogRequestResponse("TradeLicenece", "StatusCode", dataResponse.StatusCode.ToString());
                Util.LogRequestResponse("TradeLicenece", "ResponseContent", dataResponse.Content.ToString());
                if (dataResponse.StatusCode == HttpStatusCode.OK)
                {
                    string RedirectionUrl = ConfigurationManager.AppSettings["TradeLicenseRedirectionUrl"].ToString() + dataResponse.Content.ToString();
                    Util.LogRequestResponse("TradeLicenece", "RedirectUrl", RedirectionUrl);
                    Response.Redirect(RedirectionUrl, true);

                }
            }
            
      }
      catch (Exception ex)
      {
            Util.LogError(ex, "DraftService");
      }
    }
    protected void ExlbtnAll_Click(object sender, EventArgs e)
    {
        try
        {
            if (ExlbtnAll.Text == "All")
            {
                ExlbtnAll.Text = "Paging";
                this.gvExDraftService.PageIndex = 0;
                this.gvExDraftService.AllowPaging = false;
            }
            else
            {
                ExlbtnAll.Text = "All";
                this.gvExDraftService.AllowPaging = true;
            }

            BindGridDraft();
        }
        catch (Exception ex)
        {
            Util.LogError(ex, "DraftService");
        }
    }

    public static void MergeRows(GridView gridView)
    {
        for (int rowIndex = gridView.Rows.Count - 2; rowIndex >= 0; rowIndex--)
        {
            GridViewRow row = gridView.Rows[rowIndex];
            GridViewRow previousRow = gridView.Rows[rowIndex + 1];
            Label lblgrouipid = (Label)row.Cells[0].FindControl("lblgrouipid");
            Label previousRowlblgrouipid = (Label)previousRow.Cells[0].FindControl("lblgrouipid");

            if (lblgrouipid.Text != "")
            {
                if (lblgrouipid.Text == previousRowlblgrouipid.Text)
                {
                    row.Cells[0].RowSpan = previousRow.Cells[0].RowSpan < 2 ? 2 :
                                           previousRow.Cells[0].RowSpan + 1;
                    previousRow.Cells[0].Visible = false;
                    row.Cells[0].Style["vertical-align"] = "middle";
                    row.Cells[0].Style["text-align"] = "left";
                    row.Cells[6].RowSpan = previousRow.Cells[6].RowSpan < 2 ? 2 :
                                          previousRow.Cells[6].RowSpan + 1;
                    previousRow.Cells[6].Visible = false;
                    row.Cells[6].Style["vertical-align"] = "middle";
                    row.Cells[6].Style["text-align"] = "center";
                }
            }
        }
    }
}