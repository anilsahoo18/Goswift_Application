﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Pre_Populate_Incentive_Entity
/// </summary>
public class Pre_Populate_Incentive_Entity
{
    public Pre_Populate_Incentive_Entity()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public string strUserID { get; set; }
}