﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for StampDutyExemption
/// </summary>
   
    public class StampDutyExemption
    {
        public StampDutyExemption()
        {
            //
            // TODO: Add constructor logic here
            //
        }
        public int intSectionNo { get; set; }
        public int INCUNQUEID { get; set; }
        public string TypeofDeed { get; set; }
        public string OriginalDeedDoc { get; set; }
    }
