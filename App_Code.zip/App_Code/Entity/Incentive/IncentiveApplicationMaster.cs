﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EntityLayer.Incentive
{
    public class IncentiveApplicationMaster
    {
        public int INTINCUNQUEID { get; set; }
        public string VCHINCENTIVENO { get; set; }
        public int INTUSERID { get; set; }
        public string VCHPCNO { get; set; }
        public string VCHPEALNO { get; set; }
        public string VCHUNITCODE { get; set; }
        public string VCHPROPOSALNO { get; set; }


    }
}