﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for DocumentSubmittedAftComp
/// </summary>
/// CREATED BY PRAKASH SWAIN ON 9-Sept-2017
/// 
namespace EntityLayer.Incentive
{
    public class DocumentSubmittedAftComp
    {
        public string Excepteddateofcourse { get; set; }
        public string ManagementDevSuceLetter { get; set; }
    }
}