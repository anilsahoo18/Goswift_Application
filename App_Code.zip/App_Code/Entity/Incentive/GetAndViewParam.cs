﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for GetAndViewParam
/// </summary>
public class GetAndViewParam
{
    public string Param1ID { get; set; }
    public string Param2ID { get; set; }
    public string Param3ID { get; set; }
    public string Param4ID { get; set; }
    public string Param5 { get; set; }
    public string Param6 { get; set; }
    public string Param7 { get; set; }
    public DateTime? FrmDate { get; set; }
    public DateTime? Todate { get; set; }
    public int? InctType { get; set; }
}
