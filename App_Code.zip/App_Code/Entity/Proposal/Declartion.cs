﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EntityLayer.Proposal
{
    public class Declartion
    {
        public string strAction { get; set; }
        public int intDeclartion { get; set; }
        public string vchProposalno { get; set; }
        public int intCreatedBy { get; set; }
        public int intorder { get; set; }
    }
}
