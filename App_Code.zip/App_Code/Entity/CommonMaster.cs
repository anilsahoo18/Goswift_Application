﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for SectorMaster
/// </summary>
public class SectorMaster
{
	public SectorMaster()
	{
		//
		// TODO: Add constructor logic here
		//
	}
}