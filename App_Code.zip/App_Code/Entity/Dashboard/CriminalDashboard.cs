﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for CriminalDashboard
/// </summary>
namespace EntityLayer.Dashboard
{
	public class CriminalDashboard
	{
		public string strAction { get; set; }
		public string strSubDept { get; set; }
		public string  strActRulorder { get; set; }
		public string strSectionRule { get; set; }
		public string strProvisonWithTriger { get; set; }
		public string strTypeOfOffence { get; set; }
		public string strFineAmount { get; set; }
		public string strFineApplicablePerDay { get; set; }
		public string  strImprisonmentNumber { get; set; }

		public string strImprisonmentDays { get; set; }

	}
}
