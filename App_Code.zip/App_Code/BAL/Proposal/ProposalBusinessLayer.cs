﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EntityLayer.Proposal;
using DataAcessLayer.Proposal;
using System.ServiceModel;

using System.Data;

namespace BusinessLogicLayer.Proposal
{
    //public class ProposalBusinessLayer:IProposalBusinessLayer
    //{
    //    ProposalDataLayer objDataAccess = new ProposalDataLayer();
    //    public string ManPowerBAL(ManPowerDetails objManPower)
    //    {
    //        return objDataAccess.ManPowerData(objManPower);
    //    }
    //    public List<ManPowerDetails> ViewManpower(ManPowerDetails objViewmanPower)
    //    {
    //        return objDataAccess.ViewManpower(objViewmanPower);
    //    }
    //    public string AddFinacialHelth(FinancialHelth objfinalcial)
    //    {
    //        return objDataAccess.AddFinacialHelth(objfinalcial);
    //    }
    //   public List<FinancialHelth> ViewFinacialHelth(FinancialHelth objfinancial)
    //    {
    //        return objDataAccess.ViewFinacialHelth(objfinancial);
    //    }
    //   public string AddWaterDetails(WaterDetails objwater)
    //   {
    //       return objDataAccess.AddWaterDetails(objwater);
    //   }
    //   public List<WaterDetails> ViewWaterDetails(WaterDetails objwater)
    //   {
    //       return objDataAccess.ViewWaterdetails(objwater);
    //   }

    //   public string PowerDetails(PowerDetails objPower)
    //   {
    //       return objDataAccess.PowerDetails(objPower);
    //   }
    //   public List<PowerDetails> ViewPowerDetails(PowerDetails objPower)
    //   {
    //       return objDataAccess.ViewPowerDetails(objPower);
    //   }
    //   public string ProposalSiteDetails(EntitySiteDetails objProposal)
    //   {
    //       return objDataAccess.ProposalSiteDetails(objProposal);
    //   }
    //   //public DataTable ViewSiteDetails(string ProposalNo, string action)
    //   //{
    //   //    return objDataAccess.ViewSiteDetails(ProposalNo, action);
    //   //}

    //}
}
