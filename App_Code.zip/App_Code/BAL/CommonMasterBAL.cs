﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for CommonMasterBAL
/// </summary>
public class CommonMasterBAL
{
	public CommonMasterBAL()
	{
		//
		// TODO: Add constructor logic here
		//
	}
}