﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

/// <summary>
/// Summary description for IPre_Populate_Incentive_BAL
/// </summary>
public interface IPre_Populate_Incentive_BAL
{
    DataSet Pre_Populate_Inct_Data(Pre_Populate_Incentive_Entity ObjEntity);
}