﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for CommonMasterDAL
/// </summary>
public class CommonMasterDAL
{
	public CommonMasterDAL()
	{
		//
		// TODO: Add constructor logic here
		//
	}
}